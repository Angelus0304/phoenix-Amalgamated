import { getSupabaseServerClient } from "@/lib/supabase"
import fs from "fs"
import path from "path"

async function setupFunctions() {
  try {
    const supabase = getSupabaseServerClient()

    // Read the SQL file
    const sqlFilePath = path.resolve(process.cwd(), "scripts", "create-functions.sql")
    const sql = fs.readFileSync(sqlFilePath, "utf8")

    // Execute the SQL
    const { error } = await supabase.rpc("exec_sql", { sql })

    if (error) {
      console.error("Error setting up functions:", error)
      return
    }

    console.log("Database functions created successfully")
  } catch (error) {
    console.error("Error setting up functions:", error)
  }
}

// Run the function
setupFunctions()

