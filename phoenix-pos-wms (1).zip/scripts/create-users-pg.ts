import { sql } from "@/lib/db"
import { hashPassword } from "@/lib/auth"

export async function createUsersTable() {
  try {
    await sql`
      CREATE TABLE IF NOT EXISTS users (
        id SERIAL PRIMARY KEY,
        username VARCHAR(255) UNIQUE NOT NULL,
        password VARCHAR(255) NOT NULL,
        name VARCHAR(255) NOT NULL,
        email VARCHAR(255) UNIQUE NOT NULL,
        role VARCHAR(50) NOT NULL,
        created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
      )
    `
    console.log("Users table created or already exists")
    return true
  } catch (error) {
    console.error("Error creating users table:", error)
    return false
  }
}

export async function seedUsers() {
  try {
    // Check if users already exist
    const existingUsers = await sql`SELECT COUNT(*) FROM users`
    if (Number.parseInt(existingUsers[0].count) > 0) {
      console.log("Users already seeded, skipping...")
      return true
    }

    // Create default admin user
    const adminPassword = await hashPassword("admin123")
    await sql`
      INSERT INTO users (username, password, name, email, role)
      VALUES ('admin', ${adminPassword}, 'Admin User', 'admin@example.com', 'admin')
    `

    // Create default manager user
    const managerPassword = await hashPassword("manager123")
    await sql`
      INSERT INTO users (username, password, name, email, role)
      VALUES ('manager', ${managerPassword}, 'Manager User', 'manager@example.com', 'manager')
    `

    // Create default staff user
    const staffPassword = await hashPassword("staff123")
    await sql`
      INSERT INTO users (username, password, name, email, role)
      VALUES ('staff', ${staffPassword}, 'Staff User', 'staff@example.com', 'staff')
    `

    console.log("Default users seeded successfully")
    return true
  } catch (error) {
    console.error("Error seeding users:", error)
    return false
  }
}

export async function setupUsers() {
  const tableCreated = await createUsersTable()
  if (tableCreated) {
    await seedUsers()
  }
}

// Run the setup if this file is executed directly
if (require.main === module) {
  setupUsers()
    .then(() => {
      console.log("User setup completed")
      process.exit(0)
    })
    .catch((error) => {
      console.error("User setup failed:", error)
      process.exit(1)
    })
}

