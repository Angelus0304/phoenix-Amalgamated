import { getSupabaseServerClient } from "@/lib/supabase"
import fs from "fs"
import { parse } from "csv-parse"
import path from "path"

async function importCustomers() {
  try {
    const supabase = getSupabaseServerClient()

    // Path to your CSV file
    const csvFilePath = path.resolve(process.cwd(), "data", "Customer Sheet C.csv")

    const customers = []

    // Create a readable stream from the CSV file
    const parser = fs.createReadStream(csvFilePath).pipe(
      parse({
        // CSV options
        columns: true,
        skip_empty_lines: true,
        trim: true,
      }),
    )

    // Process each row
    for await (const row of parser) {
      // Extract data from CSV
      // The CSV structure is a bit complex, so we need to carefully map fields
      const name = row[2] || ""
      const address1 = row[3] || ""
      const address2 = row[4] || ""
      const phone = row[11] || row[21] || ""
      const email = row[22] || ""

      // Only add customers with at least a name
      if (name && name.trim() !== "") {
        customers.push({
          name: name.trim(),
          address: `${address1} ${address2}`.trim(),
          phone: phone.trim(),
          email: email.trim(),
          type: "Retail", // Default type
          created_at: new Date(),
        })
      }
    }

    // Insert customers in batches to avoid hitting limits
    const batchSize = 100
    for (let i = 0; i < customers.length; i += batchSize) {
      const batch = customers.slice(i, i + batchSize)
      const { error } = await supabase.from("customers").insert(batch)

      if (error) {
        console.error(`Error inserting batch ${i / batchSize + 1}:`, error)
      } else {
        console.log(`Inserted batch ${i / batchSize + 1} (${batch.length} customers)`)
      }
    }

    console.log(`Imported ${customers.length} customers successfully`)
  } catch (error) {
    console.error("Error importing customers:", error)
  }
}

// Run the function
importCustomers()

