import { getSupabaseServerClient } from "@/lib/supabase"
import { hash } from "bcrypt"

async function seedData() {
  try {
    const supabase = getSupabaseServerClient()

    // 1. Create admin user
    const saltRounds = 10
    const adminPassword = await hash("Ruky0116*", saltRounds)
    const genericPassword = await hash("Phoenix2025", saltRounds)

    // Check if admin user already exists
    const { data: existingAdmin } = await supabase.from("users").select("id").eq("username", "Angelus").maybeSingle()

    if (!existingAdmin) {
      const { error: adminError } = await supabase.from("users").insert({
        username: "Angelus",
        password: adminPassword,
        name: "Angelus",
        email: "admin@phoenixcashandcarry.com",
        role: "admin",
        created_at: new Date(),
      })

      if (adminError) {
        console.error("Error creating admin user:", adminError)
      } else {
        console.log("Admin user created successfully")
      }
    } else {
      console.log("Admin user already exists")
    }

    // 2. Create POS users
    for (let i = 1; i <= 30; i++) {
      const { data: existingUser } = await supabase.from("users").select("id").eq("username", `POS${i}`).maybeSingle()

      if (!existingUser) {
        await supabase.from("users").insert({
          username: `POS${i}`,
          password: genericPassword,
          name: `POS User ${i}`,
          email: `pos${i}@phoenixcashandcarry.com`,
          role: "pos",
          created_at: new Date(),
        })
      }
    }

    // 3. Create Telesales users
    for (let i = 1; i <= 10; i++) {
      const { data: existingUser } = await supabase
        .from("users")
        .select("id")
        .eq("username", `Telesales${i}`)
        .maybeSingle()

      if (!existingUser) {
        await supabase.from("users").insert({
          username: `Telesales${i}`,
          password: genericPassword,
          name: `Telesales User ${i}`,
          email: `telesales${i}@phoenixcashandcarry.com`,
          role: "telesales",
          created_at: new Date(),
        })
      }
    }

    // 4. Create Sales Rep users
    for (let i = 1; i <= 5; i++) {
      const { data: existingUser } = await supabase.from("users").select("id").eq("username", `Rep${i}`).maybeSingle()

      if (!existingUser) {
        await supabase.from("users").insert({
          username: `Rep${i}`,
          password: genericPassword,
          name: `Sales Rep ${i}`,
          email: `rep${i}@phoenixcashandcarry.com`,
          role: "salesrep",
          created_at: new Date(),
        })
      }
    }

    // 5. Create named Sales Rep users
    const namedReps = ["Lindo", "Suveer", "Sanele", "Wiseman", "Baskeer", "Innocent"]
    for (const name of namedReps) {
      const { data: existingUser } = await supabase.from("users").select("id").eq("username", name).maybeSingle()

      if (!existingUser) {
        await supabase.from("users").insert({
          username: name,
          password: genericPassword,
          name: name,
          email: `${name.toLowerCase()}@phoenixcashandcarry.com`,
          role: "salesrep",
          created_at: new Date(),
        })
      }
    }

    console.log("User seeding completed")

    // 6. Create product categories
    const categories = [
      { name: "Groceries", description: "Food and household items" },
      { name: "Electronics", description: "Electronic devices and accessories" },
      { name: "Clothing", description: "Apparel and fashion items" },
      { name: "Home & Garden", description: "Items for home and garden" },
      { name: "Health & Beauty", description: "Personal care and beauty products" },
    ]

    for (const category of categories) {
      const { data: existingCategory } = await supabase
        .from("product_categories")
        .select("id")
        .eq("name", category.name)
        .maybeSingle()

      if (!existingCategory) {
        await supabase.from("product_categories").insert(category)
      }
    }

    console.log("Category seeding completed")

    // 7. Create warehouses
    const warehouses = [
      { name: "Main Warehouse", location: "Durban", capacity: 10000, used: 0 },
      { name: "Secondary Warehouse", location: "Johannesburg", capacity: 5000, used: 0 },
      { name: "Distribution Center", location: "Cape Town", capacity: 8000, used: 0 },
    ]

    for (const warehouse of warehouses) {
      const { data: existingWarehouse } = await supabase
        .from("warehouses")
        .select("id")
        .eq("name", warehouse.name)
        .maybeSingle()

      if (!existingWarehouse) {
        await supabase.from("warehouses").insert(warehouse)
      }
    }

    console.log("Warehouse seeding completed")

    console.log("Database seeding completed successfully")
  } catch (error) {
    console.error("Error seeding database:", error)
  }
}

// Run the function
seedData()

