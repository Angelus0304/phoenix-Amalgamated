import { MongoClient } from "mongodb"
import { hash } from "bcrypt"

// MongoDB connection
const uri = process.env.MONGODB_URI || "mongodb://localhost:27017/phoenix_pos_wms"
const client = new MongoClient(uri)

async function createUsers() {
  try {
    await client.connect()
    console.log("Connected to MongoDB")

    const db = client.db("phoenix_pos_wms")
    const usersCollection = db.collection("users")

    // Clear existing users (optional)
    // await usersCollection.deleteMany({})

    const saltRounds = 10
    const genericPassword = await hash("Phoenix2025", saltRounds)
    const adminPassword = await hash("Ruky0116*", saltRounds)

    // Create users array
    const users = []

    // 1. Master admin user
    users.push({
      username: "Angelus",
      password: adminPassword,
      name: "Angelus",
      email: "admin@phoenixcashandcarry.com",
      role: "admin",
      created_at: new Date(),
    })

    // 2. POS Users (1-30)
    for (let i = 1; i <= 30; i++) {
      users.push({
        username: `POS${i}`,
        password: genericPassword,
        name: `POS User ${i}`,
        email: `pos${i}@phoenixcashandcarry.com`,
        role: "pos",
        created_at: new Date(),
      })
    }

    // 3. Tele-sales Users (1-10)
    for (let i = 1; i <= 10; i++) {
      users.push({
        username: `Telesales${i}`,
        password: genericPassword,
        name: `Telesales User ${i}`,
        email: `telesales${i}@phoenixcashandcarry.com`,
        role: "telesales",
        created_at: new Date(),
      })
    }

    // 4. Generic Rep Users (1-5)
    for (let i = 1; i <= 5; i++) {
      users.push({
        username: `Rep${i}`,
        password: genericPassword,
        name: `Sales Rep ${i}`,
        email: `rep${i}@phoenixcashandcarry.com`,
        role: "salesrep",
        created_at: new Date(),
      })
    }

    // 5. Named Rep Users
    const namedReps = ["Lindo", "Suveer", "Sanele", "Wiseman", "Baskeer", "Innocent"]
    namedReps.forEach((name) => {
      users.push({
        username: name,
        password: genericPassword,
        name: name,
        email: `${name.toLowerCase()}@phoenixcashandcarry.com`,
        role: "salesrep",
        created_at: new Date(),
      })
    })

    // Insert all users
    const result = await usersCollection.insertMany(users)
    console.log(`${result.insertedCount} users created successfully`)

    // List created users
    console.log("Created users:")
    users.forEach((user) => {
      console.log(`- ${user.username} (${user.role})`)
    })
  } catch (error) {
    console.error("Error creating users:", error)
  } finally {
    await client.close()
    console.log("MongoDB connection closed")
  }
}

// Run the function
createUsers()

