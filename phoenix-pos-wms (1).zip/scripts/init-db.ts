import clientPromise from "@/lib/mongodb"
import { COLLECTIONS } from "@/lib/schema"

export async function initializeDatabase() {
  try {
    const client = await clientPromise
    const db = client.db("phoenix_pos_wms")

    // Create collections if they don't exist
    const collections = await db.listCollections().toArray()
    const collectionNames = collections.map((c) => c.name)

    // Create collections
    for (const collectionName of Object.values(COLLECTIONS)) {
      if (!collectionNames.includes(collectionName)) {
        await db.createCollection(collectionName)
        console.log(`Created collection: ${collectionName}`)
      }
    }

    // Create indexes
    await db.collection(COLLECTIONS.USERS).createIndex({ username: 1 }, { unique: true })
    await db.collection(COLLECTIONS.USERS).createIndex({ email: 1 })

    await db.collection(COLLECTIONS.CUSTOMERS).createIndex({ name: 1 })
    await db.collection(COLLECTIONS.CUSTOMERS).createIndex({ email: 1 })
    await db.collection(COLLECTIONS.CUSTOMERS).createIndex({ sales_rep: 1 })

    await db.collection(COLLECTIONS.PRODUCTS).createIndex({ sku: 1 }, { unique: true })
    await db.collection(COLLECTIONS.PRODUCTS).createIndex({ name: 1 })
    await db.collection(COLLECTIONS.PRODUCTS).createIndex({ category: 1 })

    await db.collection(COLLECTIONS.ORDERS).createIndex({ customer_id: 1 })
    await db.collection(COLLECTIONS.ORDERS).createIndex({ created_at: 1 })

    await db.collection(COLLECTIONS.ORDER_ITEMS).createIndex({ order_id: 1 })
    await db.collection(COLLECTIONS.ORDER_ITEMS).createIndex({ product_id: 1 })

    await db.collection(COLLECTIONS.WAREHOUSES).createIndex({ name: 1 })

    await db
      .collection(COLLECTIONS.WAREHOUSE_PRODUCTS)
      .createIndex({ warehouse_id: 1, product_id: 1 }, { unique: true })

    return { success: true, message: "Database initialized successfully" }
  } catch (error) {
    console.error("Error initializing database:", error)
    return { success: false, error: error.message }
  }
}

