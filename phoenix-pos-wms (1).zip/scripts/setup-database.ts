import { getSupabaseServerClient } from "@/lib/supabase"
import fs from "fs"
import path from "path"

async function setupDatabase() {
  try {
    const supabase = getSupabaseServerClient()

    // Read the SQL file
    const sqlFilePath = path.resolve(process.cwd(), "scripts", "create-tables.sql")
    const sql = fs.readFileSync(sqlFilePath, "utf8")

    // Execute the SQL
    const { error } = await supabase.rpc("exec_sql", { sql })

    if (error) {
      console.error("Error setting up database:", error)
      return
    }

    console.log("Database setup completed successfully")
  } catch (error) {
    console.error("Error setting up database:", error)
  }
}

// Run the function
setupDatabase()

