import { MongoClient } from "mongodb"
import fs from "fs"
import { parse } from "csv-parse"
import path from "path"

// MongoDB connection
const uri = process.env.MONGODB_URI || process.env.DATABASE_URL
const client = new MongoClient(uri)

async function importCustomers() {
  try {
    await client.connect()
    console.log("Connected to MongoDB")

    const db = client.db("phoenix_pos_wms")
    const customersCollection = db.collection("customers")

    // Path to your CSV file
    const csvFilePath = path.resolve(process.cwd(), "data", "Customer Sheet C.csv")

    const customers = []

    // Create a readable stream from the CSV file
    const parser = fs.createReadStream(csvFilePath).pipe(
      parse({
        // CSV options
        columns: true,
        skip_empty_lines: true,
        trim: true,
      }),
    )

    // Process each row
    for await (const row of parser) {
      // Map CSV columns to customer object
      // Adjust these mappings based on your actual CSV structure
      const customer = {
        id: row[0] || `CUST-${Math.floor(Math.random() * 10000)}`,
        name: row[2] || "",
        address: `${row[3] || ""} ${row[4] || ""}`.trim(),
        phone: row[11] || row[21] || "",
        email: row[22] || "",
        type: row[5] ? "Business" : "Individual",
        created_at: new Date(),
        location: row["Location"] || "",
        notes: row[23] || "",
      }

      // Only add customers with at least a name
      if (customer.name) {
        customers.push(customer)
      }
    }

    // Insert customers into MongoDB
    if (customers.length > 0) {
      const result = await customersCollection.insertMany(customers)
      console.log(`${result.insertedCount} customers imported successfully`)
    } else {
      console.log("No valid customers found in CSV")
    }
  } catch (error) {
    console.error("Error importing customers:", error)
  } finally {
    await client.close()
    console.log("MongoDB connection closed")
  }
}

// Run the function
importCustomers()

