import { executeQuery } from "../lib/db"
import fs from "fs"
import { parse } from "csv-parse"
import path from "path"

async function importCustomers() {
  try {
    console.log("Importing customers to PostgreSQL...")

    // Path to your CSV file
    const csvFilePath = path.resolve(process.cwd(), "data", "Customer Sheet C.csv")

    // Create a readable stream from the CSV file
    const parser = fs.createReadStream(csvFilePath).pipe(
      parse({
        // CSV options
        columns: true,
        skip_empty_lines: true,
        trim: true,
      }),
    )

    let importCount = 0

    // Process each row
    for await (const row of parser) {
      // Map CSV columns to customer object
      const name = row[2] || ""
      if (!name) continue // Skip rows without a name

      const address = `${row[3] || ""} ${row[4] || ""}`.trim()
      const phone = row[11] || row[21] || ""
      const email = row[22] || ""
      const type = row[5] ? "wholesale" : "retail"
      const notes = row[23] || ""

      // Insert customer into PostgreSQL
      await executeQuery(
        `
        INSERT INTO customers (name, email, phone, address, type, notes, created_at, updated_at)
        VALUES ($1, $2, $3, $4, $5, $6, NOW(), NOW())
        `,
        [name, email, phone, address, type, notes],
      )

      importCount++
    }

    console.log(`${importCount} customers imported successfully to PostgreSQL!`)
  } catch (error) {
    console.error("Error importing customers to PostgreSQL:", error)
  }
}

// Run the function
importCustomers()

