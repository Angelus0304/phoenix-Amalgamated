-- Function to update product stock level
CREATE OR REPLACE FUNCTION update_stock_level(p_product_id UUID, p_quantity INTEGER)
RETURNS VOID AS $$
BEGIN
  UPDATE products
  SET 
    stock_level = stock_level + p_quantity,
    updated_at = NOW()
  WHERE id = p_product_id;
END;
$$ LANGUAGE plpgsql;

-- Function to update warehouse capacity
CREATE OR REPLACE FUNCTION update_warehouse_capacity(p_warehouse_id UUID, p_quantity INTEGER)
RETURNS VOID AS $$
BEGIN
  UPDATE warehouses
  SET 
    used = used + p_quantity,
    updated_at = NOW()
  WHERE id = p_warehouse_id;
END;
$$ LANGUAGE plpgsql;

-- Function to execute arbitrary SQL (for setup scripts)
CREATE OR REPLACE FUNCTION exec_sql(sql TEXT)
RETURNS VOID AS $$
BEGIN
  EXECUTE sql;
END;
$$ LANGUAGE plpgsql;

