import { exec } from "child_process"
import { promisify } from "util"

const execAsync = promisify(exec)

async function runScript(scriptPath: string): Promise<void> {
  try {
    console.log(`Running ${scriptPath}...`)
    const { stdout, stderr } = await execAsync(`npx ts-node ${scriptPath}`)

    if (stdout) console.log(stdout)
    if (stderr) console.error(stderr)

    console.log(`Completed ${scriptPath}`)
  } catch (error) {
    console.error(`Error running ${scriptPath}:`, error)
  }
}

async function setupAll() {
  try {
    // 1. Setup database tables
    await runScript("scripts/setup-database.ts")

    // 2. Setup database functions
    await runScript("scripts/setup-functions.ts")

    // 3. Seed initial data
    await runScript("scripts/seed-data.ts")

    // 4. Import customers from CSV
    await runScript("scripts/import-customers-supabase.ts")

    console.log("All setup completed successfully")
  } catch (error) {
    console.error("Error during setup:", error)
  }
}

// Run the function
setupAll()

