import clientPromise from "@/lib/mongodb"

// This is a compatibility layer for code that expects Supabase
// It provides the same interface but uses MongoDB under the hood

// Create a mock Supabase client
const createMockSupabaseClient = () => {
  return {
    from: (table: string) => ({
      select: async () => {
        const client = await clientPromise
        const db = client.db("phoenix_pos_wms")
        const data = await db.collection(table).find().toArray()
        return { data, error: null }
      },
      insert: async (data: any) => {
        try {
          const client = await clientPromise
          const db = client.db("phoenix_pos_wms")
          const result = await db.collection(table).insertOne(data)
          return { data: { ...data, id: result.insertedId }, error: null }
        } catch (error) {
          return { data: null, error }
        }
      },
      update: async (data: any) => {
        try {
          const client = await clientPromise
          const db = client.db("phoenix_pos_wms")
          await db.collection(table).updateOne({ id: data.id }, { $set: data })
          return { data, error: null }
        } catch (error) {
          return { data: null, error }
        }
      },
      delete: async () => {
        try {
          const client = await clientPromise
          const db = client.db("phoenix_pos_wms")
          await db.collection(table).deleteMany({})
          return { data: {}, error: null }
        } catch (error) {
          return { data: null, error }
        }
      },
      eq: (field: string, value: any) => ({
        select: async () => {
          const client = await clientPromise
          const db = client.db("phoenix_pos_wms")
          const data = await db
            .collection(table)
            .find({ [field]: value })
            .toArray()
          return { data, error: null }
        },
      }),
    }),
    storage: {
      from: (bucket: string) => ({
        upload: async (path: string, file: any) => {
          console.log(`Mock storage: Would upload ${path} to ${bucket}`)
          return { data: { path }, error: null }
        },
        getPublicUrl: (path: string) => {
          return { data: { publicUrl: `/api/mock-storage/${bucket}/${path}` } }
        },
      }),
    },
    auth: {
      signIn: async () => {
        console.log("Mock auth: Would sign in")
        return { data: { user: { id: "mock-user-id" } }, error: null }
      },
      signOut: async () => {
        console.log("Mock auth: Would sign out")
        return { error: null }
      },
    },
  }
}

// Create a singleton instance for client-side
let browserClient: any = null

export const getSupabaseBrowserClient = () => {
  if (!browserClient) {
    browserClient = createMockSupabaseClient()
  }
  return browserClient
}

// Create a server client (to be used in API routes and server components)
export const getSupabaseServerClient = () => {
  return createMockSupabaseClient()
}

