import { db } from "./db"
import { users } from "./schema"
import { eq } from "drizzle-orm"
import { compare, hash } from "bcrypt"

}
export type User = {
  id: number
  username: string
  name: string
  email: string
  role: string
  }
  
export async function getUserByUsername(username: string): Promise<any | null> {
  try {
     const result = await db
      .select({
        id: users.id,
        username: users.username,
        password: users.password,
        name: users.name,
        email: users.email,
        role: users.role,
      })
      .from(users)
      .where(eq(users.username, username))

    return result.length > 0 ? result[0] : null

    const result: User[] = await sql`
      SELECT * FROM users WHERE username = ${username} LIMIT 1
    `;

    return result.length ? result[0] : null;
  } catch (error) {
        console.error("Error getting user by username:", error)
    return null

    throw new Error("Database query failed.");
  }
}

export async function verifyPassword(user: any, password: string): Promise<boolean> {

  try {
       return await compare(password, user.password)
 return bcrypt.compare(password, user.password);
  } catch (error) {
        console.error("Error verifying password:", error)
    return false
  }
   return false;
  }
}

export async function hashPassword(password: string): Promise<string> {
  const saltRounds = 10;
  return bcrypt.hash(password, saltRounds);
}

export async function createUser(userData: {
  username: string
  password: string
  name: string
  email: string
  role: string
}): Promise<User | null> {

  try {
        const hashedPassword = await hash(userData.password, 10)

    const result = await db
      .insert(users)
      .values({
        username: userData.username,
        password: hashedPassword,
        name: userData.name,
        email: userData.email,
        role: userData.role,
      })
      .returning({
        id: users.id,
        username: users.username,
        name: users.name,
        email: users.email,
        role: users.role,
      })

    return result.length > 0 ? result[0] : null

   const result: User[] = await sql`
      INSERT INTO users (username, password, name, email, role)
      VALUES (${user.username}, ${hashedPassword}, ${user.name}, ${user.email}, ${user.role})
      RETURNING *
    `;

    return result[0];
  } catch (error) {
        console.error("Error creating user:", error)
    return null

    throw new Error("User creation failed.");
  }
}

export async function getUserById(id: number): Promise<User | null> {
  try {
    const result = await db
      .select({
        id: users.id,
        username: users.username,
        name: users.name,
        email: users.email,
        role: users.role,
      })
      .from(users)
      .where(eq(users.id, id))

      return result.length > 0 ? result[0] : null

    const hashedPassword = await hashPassword(newPassword);

    const result = await sql`
      UPDATE users
      SET password = ${hashedPassword}
      WHERE id = ${userId}
      RETURNING id
    `;

    return result.length > 0;
  } catch (error) {
        console.error("Error getting user by ID:", error)
    return null

    return false;
  }
}

