export interface Customer {
  id: string
  name: string
  email: string
  phone: string
  address: string
  type: string
  credit_limit?: number
  balance?: number
  sales_rep?: string
  created_at: Date
}

export interface Product {
  id: string
  name: string
  sku: string
  barcode?: string
  description: string
  category: string
  price: number
  cost: number
  tax_rate: number
  stock_level: number
  min_stock_level: number
  supplier: string
  created_at: Date
}

export interface Order {
  id: string
  customer_id: string
  customer_name: string
  items: OrderItem[]
  total: number
  tax: number
  status: string
  payment_status: string
  payment_method: string
  created_at: Date
}

export interface OrderItem {
  product_id: string
  product_name: string
  quantity: number
  price: number
  total: number
}

export interface Warehouse {
  id: string
  name: string
  location: string
  capacity: number
  used: number
  products: WarehouseProduct[]
}

export interface WarehouseProduct {
  product_id: string
  product_name: string
  quantity: number
  location: string
}

export interface User {
  id: string
  username: string
  password: string
  name: string
  email: string
  role: string
  created_at: Date
}

