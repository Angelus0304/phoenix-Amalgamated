export const userRoles = ["admin", "pos", "telesales", "salesrep"]
export const orderStatuses = ["pending", "processing", "completed", "cancelled"]
export const paymentStatuses = ["paid", "unpaid", "partial", "refunded"]
export const customerTypes = ["retail", "wholesale", "stokvel"]

// Collection names
export const COLLECTIONS = {
  USERS: "users",
  CUSTOMERS: "customers",
  PRODUCTS: "products",
  ORDERS: "orders",
  ORDER_ITEMS: "order_items",
  WAREHOUSES: "warehouses",
  WAREHOUSE_PRODUCTS: "warehouse_products",
}

// Schema definitions (for reference and validation)
export const schemas = {
  users: {
    username: { type: "string", required: true, unique: true },
    password: { type: "string", required: true },
    name: { type: "string", required: true },
    email: { type: "string", required: true },
    role: { type: "string", enum: userRoles, default: "pos" },
    created_at: { type: "date", default: Date.now },
    updated_at: { type: "date", default: Date.now },
  },

  customers: {
    name: { type: "string", required: true },
    email: { type: "string" },
    phone: { type: "string" },
    address: { type: "string" },
    type: { type: "string", enum: customerTypes, default: "retail" },
    credit_limit: { type: "number", default: 0 },
    balance: { type: "number", default: 0 },
    sales_rep: { type: "string" },
    notes: { type: "string" },
    created_at: { type: "date", default: Date.now },
    updated_at: { type: "date", default: Date.now },
  },

  products: {
    name: { type: "string", required: true },
    sku: { type: "string", required: true, unique: true },
    barcode: { type: "string" },
    description: { type: "string" },
    category: { type: "string" },
    price: { type: "number", required: true },
    cost: { type: "number", required: true },
    tax_rate: { type: "number", default: 0.15 },
    stock_level: { type: "number", default: 0 },
    min_stock_level: { type: "number", default: 0 },
    supplier: { type: "string" },
    created_at: { type: "date", default: Date.now },
    updated_at: { type: "date", default: Date.now },
  },

  orders: {
    customer_id: { type: "string", required: true },
    customer_name: { type: "string", required: true },
    total: { type: "number", required: true },
    tax: { type: "number", required: true },
    status: { type: "string", enum: orderStatuses, default: "pending" },
    payment_status: { type: "string", enum: paymentStatuses, default: "unpaid" },
    payment_method: { type: "string" },
    notes: { type: "string" },
    created_at: { type: "date", default: Date.now },
    updated_at: { type: "date", default: Date.now },
  },

  order_items: {
    order_id: { type: "string", required: true },
    product_id: { type: "string", required: true },
    product_name: { type: "string", required: true },
    quantity: { type: "number", required: true },
    price: { type: "number", required: true },
    total: { type: "number", required: true },
    created_at: { type: "date", default: Date.now },
  },

  warehouses: {
    name: { type: "string", required: true },
    location: { type: "string" },
    capacity: { type: "number", default: 1000 },
    used: { type: "number", default: 0 },
    created_at: { type: "date", default: Date.now },
    updated_at: { type: "date", default: Date.now },
  },

  warehouse_products: {
    warehouse_id: { type: "string", required: true },
    product_id: { type: "string", required: true },
    quantity: { type: "number", default: 0 },
    location: { type: "string" },
    created_at: { type: "date", default: Date.now },
    updated_at: { type: "date", default: Date.now },
  },
}

// Compatibility layer for PostgreSQL schema
// These objects are used to provide the same interface as the PostgreSQL schema
// but they're just placeholders that will be mapped to MongoDB collections

// Helper function to create a table object
const createTable = (name: string) => ({
  name,
  select: () => ({ execute: async () => [] }),
  insert: (data: any) => ({ values: () => ({ returning: () => ({ execute: async () => [data] }) }) }),
  update: (data: any) => ({ where: () => ({ execute: async () => [data] }) }),
  delete: () => ({ where: () => ({ execute: async () => [] }) }),
})

// Export table objects for compatibility
export const users = createTable(COLLECTIONS.USERS)
export const customers = createTable(COLLECTIONS.CUSTOMERS)
export const products = createTable(COLLECTIONS.PRODUCTS)
export const orders = createTable(COLLECTIONS.ORDERS)
export const orderItems = createTable(COLLECTIONS.ORDER_ITEMS)
export const warehouses = createTable(COLLECTIONS.WAREHOUSES)
export const warehouseProducts = createTable(COLLECTIONS.WAREHOUSE_PRODUCTS)

// Enums for compatibility
export const userRoleEnum = { values: userRoles }
export const orderStatusEnum = { values: orderStatuses }
export const paymentStatusEnum = { values: paymentStatuses }
export const customerTypeEnum = { values: customerTypes }

