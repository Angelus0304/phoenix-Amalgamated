// Environment variable validation and access
import process from "process"

// Application Settings
export const APP_NAME = process.env.NEXT_PUBLIC_APP_NAME || "Phoenix Cash & Carry"
export const APP_URL = process.env.NEXT_PUBLIC_APP_URL || "http://localhost:3000"
export const API_URL = process.env.NEXT_PUBLIC_API_URL || "/api"
export const COMPANY_NAME = process.env.NEXT_PUBLIC_COMPANY_NAME || "Phoenix Cash & Carry PTY LTD"
export const SUPPORT_EMAIL = process.env.NEXT_PUBLIC_SUPPORT_EMAIL || "support@phoenixcashandcarry.com"
export const SUPPORT_PHONE = process.env.NEXT_PUBLIC_SUPPORT_PHONE || "+27 123 456 789"
export const LOGO_URL =
  process.env.NEXT_PUBLIC_LOGO_URL ||
  "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Phoenix%20Logo%204k.jpg-KBgMefUTREIIcFQRFEoEHwJZSzrAxw.jpeg"

// Phoenix Integration
export const PHOENIX_WMS_POS_INT = process.env.PhoenixWMSPOSINT || "PHOENIXCC"

// Feature Flags
export const ENABLE_INVENTORY_ALERTS = process.env.ENABLE_INVENTORY_ALERTS === "true"
export const ENABLE_ORDER_NOTIFICATIONS = process.env.ENABLE_ORDER_NOTIFICATIONS === "true"
export const ENABLE_CUSTOMER_PORTAL = process.env.ENABLE_CUSTOMER_PORTAL === "true"
export const ENABLE_ANALYTICS_DASHBOARD = process.env.ENABLE_ANALYTICS_DASHBOARD === "true"

// Tax Configuration
export const DEFAULT_TAX_RATE = Number(process.env.DEFAULT_TAX_RATE || "0.15")
export const TAX_CALCULATION_METHOD = process.env.TAX_CALCULATION_METHOD || "inclusive"

// System Configuration
export const IS_PRODUCTION = process.env.NODE_ENV === "production"
export const IS_DEVELOPMENT = process.env.NODE_ENV === "development"
export const IS_TEST = process.env.NODE_ENV === "test"
export const PORT = Number(process.env.PORT || "3000")

// Wholesale Configuration
export const WHOLESALE_PRICING = process.env.P_WHOLESALE_PRICING === "true"
export const WHOLESALE_MIN_QUANTITY = Number(process.env.P_WHOLESALE_MIN_QUANTITY || "1")
export const WHOLESALE_DISCOUNT = process.env.P_WHOLESALE_DISCOUNT || "0%"
export const WHOLESALE_CREDIT_LIMIT = Number(process.env.P_WHOLESALE_CREDIT_LIMIT || "1000")
export const WHOLESALE_INVOICE_TERMS = process.env.P_WHOLESALE_INVOICE_TERMS || "Net30"
export const WHOLESALE_TAX_EXEMPTION = process.env.P_WHOLESALE_TAX_EXEMPTION === "true"
export const WHOLESALE_ORDER_APPROVAL = process.env.P_WHOLESALE_ORDER_APPROVAL === "true"
export const WHOLESALE_STOCK_ALLOCATION = process.env.P_WHOLESALE_STOCK_ALLOCATION || "automatic"
export const WHOLESALE_RETURNS_POLICY = process.env.P_WHOLESALE_RETURNS_POLICY || "standard"
export const WHOLESALE_CUSTOMER_TYPES = (process.env.P_WHOLESALE_CUSTOMER_TYPES || "retailer,distributor").split(",")
export const WHOLESALE_PAYMENT_GATEWAY = process.env.P_WHOLESALE_PAYMENT_GATEWAY || "stripe"

// Sales Rep Configuration
export const SALESREP_ASSIGN = process.env.P_SALESREP_ASSIGN || "enabled"
export const SALESREP_ROUTE_LIST = process.env.P_SALESREP_ROUTE_LIST || "default"
export const SALESREP_GEOTRACKING = process.env.P_SALESREP_GEOTRACKING === "true"
export const SALESREP_TARGETS = Number(process.env.P_SALESREP_TARGETS || "5000")
export const SALESREP_INCENTIVES = process.env.P_SALESREP_INCENTIVES || "commission"
export const SALESREP_LIVE_QUOTING = process.env.P_SALESREP_LIVE_QUOTING === "true"
export const SALESREP_ORDER_PLACEMENT = process.env.P_SALESREP_ORDER_PLACEMENT === "true"
export const SALESREP_CUSTOMER_NOTES = process.env.P_SALESREP_CUSTOMER_NOTES || "enabled"
export const SALESREP_PERFORMANCE_ANALYTICS = process.env.P_SALESREP_PERFORMANCE_ANALYTICS === "true"
export const SALESREP_CUSTOMER_FEEDBACK = process.env.P_SALESREP_CUSTOMER_FEEDBACK || "enabled"

// Stokvel Group Management
export const STOKVEL_GROUP_MANAGEMENT = process.env.P_STOKVEL_GROUP_MANAGEMENT || "enabled"
export const STOKVEL_MEMBER_LIST = process.env.P_STOKVEL_MEMBER_LIST || "default"
export const STOKVEL_CONTRIBUTION_TRACKING = process.env.P_STOKVEL_CONTRIBUTION_TRACKING === "true"
export const STOKVEL_PAYMENT_SCHEDULE = process.env.P_STOKVEL_PAYMENT_SCHEDULE || "monthly"
export const STOKVEL_BULK_DISCOUNT = process.env.P_STOKVEL_BULK_DISCOUNT || "5%"
export const STOKVEL_ORDER_SPLITTING = process.env.P_STOKVEL_ORDER_SPLITTING || "enabled"
export const STOKVEL_COLLECTION_SCHEDULE = process.env.P_STOKVEL_COLLECTION_SCHEDULE || "weekly"
export const STOKVEL_LEADER_APPROVAL = process.env.P_STOKVEL_LEADER_APPROVAL === "true"

// Bulk Order Settings
export const BULK_ORDER_DISCOUNT = process.env.P_BULK_ORDER_DISCOUNT || "10%"
export const BULK_ORDER_SHIPPING_OPTIONS = (process.env.P_BULK_ORDER_SHIPPING_OPTIONS || "standard,express").split(",")
export const BULK_ORDER_WAREHOUSE_ASSIGNMENT = process.env.P_BULK_ORDER_WAREHOUSE_ASSIGNMENT || "automatic"
export const BULK_ORDER_QUOTE_REQUEST = process.env.P_BULK_ORDER_QUOTE_REQUEST || "enabled"
export const BULK_ORDER_APPROVAL_PROCESS = process.env.P_BULK_ORDER_APPROVAL_PROCESS || "manual"
export const BULK_ORDER_PAYMENT_TERMS = process.env.P_BULK_ORDER_PAYMENT_TERMS || "Net60"
export const BULK_ORDER_STOCK_RESERVATION = process.env.P_BULK_ORDER_STOCK_RESERVATION || "enabled"

// Customer Information
export const CUSTOMER_COMPANY_NAME = process.env.P_CUSTOMER_COMPANY_NAME || "default"
export const CUSTOMER_BUSINESS_TYPE = process.env.P_CUSTOMER_BUSINESS_TYPE || "retail"
export const CUSTOMER_BULK_BUYING_STATUS = process.env.P_CUSTOMER_BULK_BUYING_STATUS || "active"
export const CUSTOMER_PURCHASE_HISTORY = process.env.P_CUSTOMER_PURCHASE_HISTORY || "enabled"
export const CUSTOMER_LOYALTY_TIER = process.env.P_CUSTOMER_LOYALTY_TIER || "bronze"
export const CUSTOMER_SALES_REP_ASSIGNMENT = process.env.P_CUSTOMER_SALES_REP_ASSIGNMENT || "automatic"
export const CUSTOMER_CREDIT_STATUS = process.env.P_CUSTOMER_CREDIT_STATUS || "good"
export const CUSTOMER_ACCOUNT_AGE = Number(process.env.P_CUSTOMER_ACCOUNT_AGE || "0")
export const CUSTOMER_DISCOUNT_LEVEL = process.env.P_CUSTOMER_DISCOUNT_LEVEL || "standard"
export const CUSTOMER_ORDER_FREQUENCY = process.env.P_CUSTOMER_ORDER_FREQUENCY || "monthly"

// Warehouse Stock Levels
export const WAREHOUSE_1_STOCK_LEVEL = Number(process.env.P_WAREHOUSE_1_STOCK_LEVEL || "1000")
export const WAREHOUSE_2_STOCK_LEVEL = Number(process.env.P_WAREHOUSE_2_STOCK_LEVEL || "500")
export const WAREHOUSE_3_STOCK_LEVEL = Number(process.env.P_WAREHOUSE_3_STOCK_LEVEL || "300")
export const WAREHOUSE_4_STOCK_LEVEL = Number(process.env.P_WAREHOUSE_4_STOCK_LEVEL || "200")

// Receiving Port Status
export const RECEIVING_PORT_1_STATUS = process.env.P_RECEIVING_PORT_1_STATUS || "active"
export const RECEIVING_PORT_2_STATUS = process.env.P_RECEIVING_PORT_2_STATUS || "inactive"
export const RECEIVING_PORT_3_STATUS = process.env.P_RECEIVING_PORT_3_STATUS || "active"
export const GRV_CAPTURE_SYSTEM = process.env.P_GRV_CAPTURE_SYSTEM || "enabled"
export const WAREHOUSE_AUTO_ALLOCATION = process.env.P_WAREHOUSE_AUTO_ALLOCATION === "true"

// E-commerce Integration
export const ECOMM_STOCK_SYNC = process.env.P_ECOMM_STOCK_SYNC === "true"
export const ECOMM_PRICE_SYNC = process.env.P_ECOMM_PRICE_SYNC === "true"
export const ECOMM_ABANDONED_CART_RECOVERY = process.env.P_ECOMM_ABANDONED_CART_RECOVERY || "enabled"
export const ECOMM_WHOLESALE_ACCOUNT = process.env.P_ECOMM_WHOLESALE_ACCOUNT || "enabled"
export const ECOMM_DYNAMIC_DISCOUNTING = process.env.P_ECOMM_DYNAMIC_DISCOUNTING === "true"
export const ECOMM_AUTO_UPSELL = process.env.P_ECOMM_AUTO_UPSELL || "enabled"
export const ECOMM_CROSS_SHIPPING_OPTIONS = (process.env.P_ECOMM_CROSS_SHIPPING_OPTIONS || "standard,express").split(
  ",",
)

// Add the P environment variable to the exports
export const P = process.env.P || "production"

