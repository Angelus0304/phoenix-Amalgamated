import { z } from "zod"

// User validation schema
export const userSchema = z.object({
  username: z.string().min(3).max(50),
  password: z.string().min(6).max(100).optional(),
  name: z.string().min(2).max(100),
  email: z.string().email(),
  role: z.enum(["admin", "pos", "telesales", "salesrep"]),
})

// Customer validation schema
export const customerSchema = z.object({
  name: z.string().min(2).max(100),
  email: z.string().email().optional().nullable(),
  phone: z.string().optional().nullable(),
  address: z.string().optional().nullable(),
  type: z.enum(["retail", "wholesale", "stokvel"]).default("retail"),
  credit_limit: z.number().default(0),
  balance: z.number().default(0),
  sales_rep: z.string().optional().nullable(),
  notes: z.string().optional().nullable(),
})

// Product validation schema
export const productSchema = z.object({
  name: z.string().min(2).max(100),
  sku: z.string().min(2).max(50),
  barcode: z.string().optional().nullable(),
  description: z.string().optional().nullable(),
  category: z.string().optional().nullable(),
  price: z.number().positive(),
  cost: z.number().positive(),
  tax_rate: z.number().default(0.15),
  stock_level: z.number().default(0),
  min_stock_level: z.number().default(0),
  supplier: z.string().optional().nullable(),
})

// Order validation schema
export const orderItemSchema = z.object({
  product_id: z.number(),
  product_name: z.string(),
  quantity: z.number().positive(),
  price: z.number().positive(),
  total: z.number().positive(),
})

export const orderSchema = z.object({
  customer_id: z.number(),
  customer_name: z.string(),
  total: z.number().positive(),
  tax: z.number().nonnegative(),
  status: z.enum(["pending", "processing", "completed", "cancelled"]).default("pending"),
  payment_status: z.enum(["paid", "unpaid", "partial", "refunded"]).default("unpaid"),
  payment_method: z.string().optional().nullable(),
  notes: z.string().optional().nullable(),
  items: z.array(orderItemSchema),
})

// Warehouse validation schema
export const warehouseSchema = z.object({
  name: z.string().min(2).max(100),
  location: z.string().optional().nullable(),
  capacity: z.number().positive().default(1000),
  used: z.number().nonnegative().default(0),
})

// Warehouse product validation schema
export const warehouseProductSchema = z.object({
  warehouse_id: z.number(),
  product_id: z.number(),
  quantity: z.number().nonnegative(),
  location: z.string().optional().nullable(),
})

// Pagination parameters
export const paginationSchema = z.object({
  page: z.coerce.number().positive().default(1),
  limit: z.coerce.number().positive().max(100).default(10),
  sort: z.string().optional(),
  order: z.enum(["asc", "desc"]).default("asc"),
})

