import clientPromise from "@/lib/mongodb"
import { ObjectId } from "mongodb"

// Database name
const DB_NAME = "phoenix_pos_wms"

// Create a dummy db object for compatibility with PostgreSQL code
export const db = {
  insert: async (table: any, data: any) => {
    const client = await clientPromise
    const db = client.db(DB_NAME)
    const result = await db.collection(table.name).insertOne(data)
    return { ...data, id: result.insertedId }
  },
  select: async (table: any) => {
    const client = await clientPromise
    const db = client.db(DB_NAME)
    return await db.collection(table.name).find().toArray()
  },
  delete: async (table: any, condition: any) => {
    const client = await clientPromise
    const db = client.db(DB_NAME)
    return await db.collection(table.name).deleteOne(condition)
  },
  update: async (table: any, data: any, condition: any) => {
    const client = await clientPromise
    const db = client.db(DB_NAME)
    return await db.collection(table.name).updateOne(condition, { $set: data })
  },
}

// SQL compatibility layer
export const sql = {
  raw: (query: string, ...args: any[]) => {
    console.log("SQL query (not executed):", query, args)
    return {
      execute: async () => {
        console.log("This is a compatibility layer. SQL queries are not executed.")
        return []
      },
    }
  },
}

// Helper function to execute a query (compatibility layer)
export async function executeQuery(query: string, params: any[] = []) {
  console.log("executeQuery called with:", query, params)
  // This is just a compatibility layer
  return []
}

// Helper function to get the database
export async function getDatabase() {
  const client = await clientPromise
  return client.db(DB_NAME)
}

// Helper function to execute a database operation
export async function executeDbOperation(operation: (db: any) => Promise<any>) {
  try {
    const db = await getDatabase()
    return await operation(db)
  } catch (error) {
    console.error("Database operation error:", error)
    throw error
  }
}

// Helper function to check database connection
export async function checkConnection() {
  try {
    const client = await clientPromise
    const adminDb = client.db().admin()
    const result = await adminDb.ping()
    return { connected: result.ok === 1, timestamp: new Date() }
  } catch (error) {
    console.error("Database connection error:", error)
    return { connected: false, error }
  }
}

// Helper function to convert string ID to ObjectId
export function toObjectId(id: string) {
  try {
    return new ObjectId(id)
  } catch (error) {
    throw new Error(`Invalid ID format: ${id}`)
  }
}

// Helper function to convert ObjectId to string
export function fromObjectId(id: ObjectId) {
  return id.toString()
}

// Helper function to handle MongoDB document IDs
export function formatDocument(doc: any) {
  if (!doc) return null

  // Convert _id to id string
  if (doc._id) {
    doc.id = doc._id.toString()
    delete doc._id
  }

  return doc
}

// Helper function to format multiple documents
export function formatDocuments(docs: any[]) {
  return docs.map(formatDocument)
}

