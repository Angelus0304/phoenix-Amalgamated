export async function getCustomers() {
  return [
    {
      id: "1",
      name: "John Doe",
      email: "john.doe@example.com",
      phone: "123-456-7890",
      address: "123 Main St",
      type: "Retail",
      created_at: new Date(),
    },
    {
      id: "2",
      name: "Jane Smith",
      email: "jane.smith@example.com",
      phone: "987-654-3210",
      address: "456 Elm St",
      type: "Wholesale",
      created_at: new Date(),
    },
  ]
}

export async function getProducts() {
  return [
    {
      id: "1",
      name: "Product A",
      sku: "PA001",
      description: "Description of Product A",
      category: "Category 1",
      price: 19.99,
      cost: 9.99,
      tax_rate: 0.15,
      stock_level: 100,
      min_stock_level: 10,
      supplier: "Supplier X",
      created_at: new Date(),
    },
    {
      id: "2",
      name: "Product B",
      sku: "PB002",
      description: "Description of Product B",
      category: "Category 2",
      price: 29.99,
      cost: 14.99,
      tax_rate: 0.15,
      stock_level: 50,
      min_stock_level: 5,
      supplier: "Supplier Y",
      created_at: new Date(),
    },
  ]
}

export async function getOrders() {
  return [
    {
      id: "1",
      customer_id: "1",
      customer_name: "John Doe",
      items: [
        {
          product_id: "1",
          product_name: "Product A",
          quantity: 2,
          price: 19.99,
          total: 39.98,
        },
      ],
      total: 39.98,
      tax: 6.0,
      status: "Pending",
      payment_status: "Unpaid",
      payment_method: "Credit Card",
      created_at: new Date(),
    },
    {
      id: "2",
      customer_id: "2",
      customer_name: "Jane Smith",
      items: [
        {
          product_id: "2",
          product_name: "Product B",
          quantity: 1,
          price: 29.99,
          total: 29.99,
        },
      ],
      total: 29.99,
      tax: 4.5,
      status: "Completed",
      payment_status: "Paid",
      payment_method: "PayPal",
      created_at: new Date(),
    },
  ]
}

export async function getWarehouseStock() {
  return [
    {
      id: "1",
      name: "Warehouse A",
      location: "Location A",
      capacity: 1000,
      used: 500,
      products: [
        {
          product_id: "1",
          product_name: "Product A",
          quantity: 50,
          location: "Shelf 1",
        },
      ],
    },
    {
      id: "2",
      name: "Warehouse B",
      location: "Location B",
      capacity: 2000,
      used: 1000,
      products: [
        {
          product_id: "2",
          product_name: "Product B",
          quantity: 100,
          location: "Shelf 2",
        },
      ],
    },
  ]
}

