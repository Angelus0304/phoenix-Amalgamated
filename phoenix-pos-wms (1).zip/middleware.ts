import { NextResponse } from "next/server"
import type { NextRequest } from "next/server"
import { getToken } from "next-auth/jwt"

export async function middleware(request: NextRequest) {
  const { pathname } = request.nextUrl

  // Exclude public paths from authentication
  if (pathname.startsWith("/_next") || pathname.startsWith("/api/auth") || pathname === "/" || pathname === "/login") {
    return NextResponse.next()
  }

  const token = await getToken({ req: request })

  // Redirect to login if not authenticated
  if (!token && pathname !== "/login") {
    const url = new URL("/login", request.url)
    url.searchParams.set("callbackUrl", encodeURI(pathname))
    return NextResponse.redirect(url)
  }

  // Allow authenticated users to access protected routes
  return NextResponse.next()
}

export const config = {
  matcher: ["/((?!_next/static|_next/image|favicon.ico).*)"],
}

