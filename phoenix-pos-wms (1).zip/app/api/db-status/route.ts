import { NextResponse } from "next/server"
import { checkConnection } from "@/lib/db"

export async function GET() {
  try {
    const status = await checkConnection()
    return NextResponse.json(status)
  } catch (error) {
    console.error("Error checking database status:", error)
    return NextResponse.json({ connected: false, error: error.message }, { status: 500 })
  }
}

