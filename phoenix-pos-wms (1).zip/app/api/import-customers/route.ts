import { NextResponse } from "next/server"
import { getServerSession } from "next-auth/next"
import clientPromise from "@/lib/mongodb"
import fs from "fs"
import { parse } from "csv-parse/sync"
import path from "path"

export async function POST(request: Request) {
  try {
    const session = await getServerSession()

    // Check if user is authenticated and has admin role
    if (!session || session.user.role !== "admin") {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const client = await clientPromise
    const db = client.db("phoenix_pos_wms")
    const customersCollection = db.collection("customers")

    // Path to your CSV file
    const csvFilePath = path.resolve(process.cwd(), "data", "Customer Sheet C.csv")

    // Read and parse the CSV file
    const fileContent = fs.readFileSync(csvFilePath, "utf8")
    const records = parse(fileContent, {
      columns: true,
      skip_empty_lines: true,
      trim: true,
    })

    const customers = []

    // Process each row
    for (const row of records) {
      // Map CSV columns to customer object
      // Adjust these mappings based on your actual CSV structure
      const customer = {
        id: row[0] || `CUST-${Math.floor(Math.random() * 10000)}`,
        name: row[2] || "",
        address: `${row[3] || ""} ${row[4] || ""}`.trim(),
        phone: row[11] || row[21] || "",
        email: row[22] || "",
        type: row[5] ? "Business" : "Individual",
        created_at: new Date(),
        location: row["Location"] || "",
        notes: row[23] || "",
      }

      // Only add customers with at least a name
      if (customer.name) {
        customers.push(customer)
      }
    }

    // Insert customers into MongoDB
    if (customers.length > 0) {
      const result = await customersCollection.insertMany(customers)
      return NextResponse.json({
        success: true,
        message: `${result.insertedCount} customers imported successfully`,
      })
    } else {
      return NextResponse.json({
        success: false,
        message: "No valid customers found in CSV",
      })
    }
  } catch (error) {
    console.error("Error importing customers:", error)
    return NextResponse.json({ error: "Failed to import customers" }, { status: 500 })
  }
}

