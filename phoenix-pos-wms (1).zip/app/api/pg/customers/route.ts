import { NextResponse } from "next/server"
import { db } from "@/lib/db"
import { customers } from "@/lib/schema"
import { customerSchema, paginationSchema } from "@/lib/validations"
import { desc, asc, sql } from "drizzle-orm"

// GET all customers with pagination
export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url)

    // Validate pagination parameters
    const validatedParams = paginationSchema.parse({
      page: searchParams.get("page") || 1,
      limit: searchParams.get("limit") || 10,
      sort: searchParams.get("sort") || "id",
      order: searchParams.get("order") || "desc",
    })

    const { page, limit, sort, order } = validatedParams

    // Calculate offset
    const offset = (page - 1) * limit

    // Determine sort column and order
    const sortColumn = customers[sort as keyof typeof customers] || customers.id
    const orderFn = order === "asc" ? asc : desc

    // Count total customers
    const countResult = await db.select({ count: sql`count(*)` }).from(customers)
    const total = Number(countResult[0].count)

    // Get paginated customers
    const allCustomers = await db.select().from(customers).orderBy(orderFn(sortColumn)).limit(limit).offset(offset)

    // Calculate total pages
    const totalPages = Math.ceil(total / limit)

    return NextResponse.json({
      data: allCustomers,
      pagination: {
        total,
        page,
        limit,
        totalPages,
        hasNextPage: page < totalPages,
        hasPrevPage: page > 1,
      },
    })
  } catch (error) {
    console.error("Error fetching customers:", error)
    return NextResponse.json({ error: "Failed to fetch customers" }, { status: 500 })
  }
}

// POST new customer with validation
export async function POST(request: Request) {
  try {
    const data = await request.json()

    // Validate customer data
    const validatedData = customerSchema.parse(data)

    const newCustomer = await db
      .insert(customers)
      .values({
        name: validatedData.name,
        email: validatedData.email,
        phone: validatedData.phone,
        address: validatedData.address,
        type: validatedData.type,
        credit_limit: validatedData.credit_limit,
        balance: validatedData.balance,
        sales_rep: validatedData.sales_rep,
        notes: validatedData.notes,
      })
      .returning()

    return NextResponse.json(newCustomer[0])
  } catch (error) {
    console.error("Error creating customer:", error)

    // Check if it's a validation error
    if (error.name === "ZodError") {
      return NextResponse.json({ error: "Validation error", details: error.errors }, { status: 400 })
    }

    return NextResponse.json({ error: "Failed to create customer" }, { status: 500 })
  }
}

