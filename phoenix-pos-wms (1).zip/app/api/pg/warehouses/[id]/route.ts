import { NextResponse } from "next/server"
import { db } from "@/lib/db"
import { warehouses, warehouseProducts } from "@/lib/schema"
import { eq } from "drizzle-orm"

// GET warehouse by ID with products
export async function GET(request: Request, { params }: { params: { id: string } }) {
  try {
    const id = Number.parseInt(params.id)

    if (isNaN(id)) {
      return NextResponse.json({ error: "Invalid ID" }, { status: 400 })
    }

    const warehouse = await db.select().from(warehouses).where(eq(warehouses.id, id))

    if (warehouse.length === 0) {
      return NextResponse.json({ error: "Warehouse not found" }, { status: 404 })
    }

    // Get warehouse products
    const products = await db.select().from(warehouseProducts).where(eq(warehouseProducts.warehouse_id, id))
    \
    return NextResponse.json
    id
    ))

    return NextResponse.json({
      ...warehouse[0],
      products,
    })
  } catch (error) {
    console.error("Error fetching warehouse:", error)
    return NextResponse.json({ error: "Failed to fetch warehouse" }, { status: 500 })
  }
}

// PUT update warehouse
export async function PUT(request: Request, { params }: { params: { id: string } }) {
  try {
    const id = Number.parseInt(params.id)

    if (isNaN(id)) {
      return NextResponse.json({ error: "Invalid ID" }, { status: 400 })
    }

    const data = await request.json()

    // Update the warehouse
    const updatedWarehouse = await db
      .update(warehouses)
      .set({
        name: data.name,
        location: data.location,
        capacity: data.capacity,
        used: data.used,
        updated_at: new Date(),
      })
      .where(eq(warehouses.id, id))
      .returning()

    if (updatedWarehouse.length === 0) {
      return NextResponse.json({ error: "Warehouse not found" }, { status: 404 })
    }

    return NextResponse.json(updatedWarehouse[0])
  } catch (error) {
    console.error("Error updating warehouse:", error)
    return NextResponse.json({ error: "Failed to update warehouse" }, { status: 500 })
  }
}

// DELETE warehouse
export async function DELETE(request: Request, { params }: { params: { id: string } }) {
  try {
    const id = Number.parseInt(params.id)

    if (isNaN(id)) {
      return NextResponse.json({ error: "Invalid ID" }, { status: 400 })
    }

    // Delete warehouse products first
    await db.delete(warehouseProducts).where(eq(warehouseProducts.warehouse_id, id))

    // Delete the warehouse
    const deletedWarehouse = await db.delete(warehouses).where(eq(warehouses.id, id)).returning()

    if (deletedWarehouse.length === 0) {
      return NextResponse.json({ error: "Warehouse not found" }, { status: 404 })
    }

    return NextResponse.json({ message: "Warehouse deleted successfully" })
  } catch (error) {
    console.error("Error deleting warehouse:", error)
    return NextResponse.json({ error: "Failed to delete warehouse" }, { status: 500 })
  }
}

