import { NextResponse } from "next/server"
import { db } from "@/lib/db"
import { warehouses } from "@/lib/schema"

// GET all warehouses
export async function GET() {
  try {
    const allWarehouses = await db.select().from(warehouses)
    return NextResponse.json(allWarehouses)
  } catch (error) {
    console.error("Error fetching warehouses:", error)
    return NextResponse.json({ error: "Failed to fetch warehouses" }, { status: 500 })
  }
}

// POST new warehouse
export async function POST(request: Request) {
  try {
    const data = await request.json()

    // Validate required fields
    if (!data.name) {
      return NextResponse.json({ error: "Name is required" }, { status: 400 })
    }

    const newWarehouse = await db
      .insert(warehouses)
      .values({
        name: data.name,
        location: data.location || null,
        capacity: data.capacity || 1000,
        used: data.used || 0,
      })
      .returning()

    return NextResponse.json(newWarehouse[0])
  } catch (error) {
    console.error("Error creating warehouse:", error)
    return NextResponse.json({ error: "Failed to create warehouse" }, { status: 500 })
  }
}

