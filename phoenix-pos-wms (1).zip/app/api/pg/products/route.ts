import { NextResponse } from "next/server"
import { db } from "@/lib/db"
import { products } from "@/lib/schema"

// GET all products
export async function GET() {
  try {
    const allProducts = await db.select().from(products)
    return NextResponse.json(allProducts)
  } catch (error) {
    console.error("Error fetching products:", error)
    return NextResponse.json({ error: "Failed to fetch products" }, { status: 500 })
  }
}

// POST new product
export async function POST(request: Request) {
  try {
    const data = await request.json()

    // Validate required fields
    if (!data.name || !data.sku || !data.price || !data.cost) {
      return NextResponse.json({ error: "Name, SKU, price, and cost are required" }, { status: 400 })
    }

    const newProduct = await db
      .insert(products)
      .values({
        name: data.name,
        sku: data.sku,
        barcode: data.barcode || null,
        description: data.description || null,
        category: data.category || null,
        price: data.price,
        cost: data.cost,
        tax_rate: data.tax_rate || 0.15,
        stock_level: data.stock_level || 0,
        min_stock_level: data.min_stock_level || 0,
        supplier: data.supplier || null,
      })
      .returning()

    return NextResponse.json(newProduct[0])
  } catch (error) {
    console.error("Error creating product:", error)
    return NextResponse.json({ error: "Failed to create product" }, { status: 500 })
  }
}

