import { NextResponse } from "next/server"
import { db } from "@/lib/db"
import { orders, orderItems } from "@/lib/schema"
import { eq } from "drizzle-orm"

// GET order by ID with items
export async function GET(request: Request, { params }: { params: { id: string } }) {
  try {
    const id = Number.parseInt(params.id)

    if (isNaN(id)) {
      return NextResponse.json({ error: "Invalid ID" }, { status: 400 })
    }

    const order = await db.select().from(orders).where(eq(orders.id, id))

    if (order.length === 0) {
      return NextResponse.json({ error: "Order not found" }, { status: 404 })
    }

    // Get order items
    const items = await db.select().from(orderItems).where(eq(orderItems.order_id, id))

    return NextResponse.json({
      ...order[0],
      items,
    })
  } catch (error) {
    console.error("Error fetching order:", error)
    return NextResponse.json({ error: "Failed to fetch order" }, { status: 500 })
  }
}

// PUT update order
export async function PUT(request: Request, { params }: { params: { id: string } }) {
  try {
    const id = Number.parseInt(params.id)

    if (isNaN(id)) {
      return NextResponse.json({ error: "Invalid ID" }, { status: 400 })
    }

    const data = await request.json()

    // Update the order
    const updatedOrder = await db
      .update(orders)
      .set({
        status: data.status,
        payment_status: data.payment_status,
        payment_method: data.payment_method,
        notes: data.notes,
        updated_at: new Date(),
      })
      .where(eq(orders.id, id))
      .returning()

    if (updatedOrder.length === 0) {
      return NextResponse.json({ error: "Order not found" }, { status: 404 })
    }

    // Get order items
    const items = await db.select().from(orderItems).where(eq(orderItems.order_id, id))

    return NextResponse.json({
      ...updatedOrder[0],
      items,
    })
  } catch (error) {
    console.error("Error updating order:", error)
    return NextResponse.json({ error: "Failed to update order" }, { status: 500 })
  }
}

// DELETE order
export async function DELETE(request: Request, { params }: { params: { id: string } }) {
  try {
    const id = Number.parseInt(params.id)

    if (isNaN(id)) {
      return NextResponse.json({ error: "Invalid ID" }, { status: 400 })
    }

    // Delete order items first
    await db.delete(orderItems).where(eq(orderItems.order_id, id))

    // Delete the order
    const deletedOrder = await db.delete(orders).where(eq(orders.id, id)).returning()

    if (deletedOrder.length === 0) {
      return NextResponse.json({ error: "Order not found" }, { status: 404 })
    }

    return NextResponse.json({ message: "Order deleted successfully" })
  } catch (error) {
    console.error("Error deleting order:", error)
    return NextResponse.json({ error: "Failed to delete order" }, { status: 500 })
  }
}

