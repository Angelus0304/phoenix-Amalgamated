import { NextResponse } from "next/server"
import { db } from "@/lib/db"
import { orders, orderItems } from "@/lib/schema"

// GET all orders
export async function GET() {
  try {
    const allOrders = await db.select().from(orders)
    return NextResponse.json(allOrders)
  } catch (error) {
    console.error("Error fetching orders:", error)
    return NextResponse.json({ error: "Failed to fetch orders" }, { status: 500 })
  }
}

// POST new order
export async function POST(request: Request) {
  try {
    const data = await request.json()

    // Validate required fields
    if (!data.customer_id || !data.customer_name || !data.items || data.items.length === 0) {
      return NextResponse.json({ error: "Customer ID, name, and items are required" }, { status: 400 })
    }

    // Calculate totals
    let total = 0
    let tax = 0

    data.items.forEach((item: any) => {
      total += item.total
      // Assuming tax is included in the total
      tax += (item.total * 0.15) / 1.15 // Extract tax from total assuming 15% tax rate
    })

    // Create the order
    const newOrder = await db
      .insert(orders)
      .values({
        customer_id: data.customer_id,
        customer_name: data.customer_name,
        total: total,
        tax: tax,
        status: data.status || "pending",
        payment_status: data.payment_status || "unpaid",
        payment_method: data.payment_method || null,
        notes: data.notes || null,
      })
      .returning()

    const orderId = newOrder[0].id

    // Create order items
    for (const item of data.items) {
      await db.insert(orderItems).values({
        order_id: orderId,
        product_id: item.product_id,
        product_name: item.product_name,
        quantity: item.quantity,
        price: item.price,
        total: item.total,
      })
    }

    // Return the created order with items
    const createdOrder = {
      ...newOrder[0],
      items: data.items,
    }

    return NextResponse.json(createdOrder)
  } catch (error) {
    console.error("Error creating order:", error)
    return NextResponse.json({ error: "Failed to create order" }, { status: 500 })
  }
}

