import { NextResponse } from "next/server"
import { db } from "@/lib/db"
import { warehouseProducts, products, warehouses } from "@/lib/schema"
import { eq, and } from "drizzle-orm"

// POST new warehouse product
export async function POST(request: Request) {
  try {
    const data = await request.json()

    // Validate required fields
    if (!data.warehouse_id || !data.product_id || !data.quantity) {
      return NextResponse.json({ error: "Warehouse ID, product ID, and quantity are required" }, { status: 400 })
    }

    // Check if warehouse exists
    const warehouse = await db.select().from(warehouses).where(eq(warehouses.id, data.warehouse_id))
    if (warehouse.length === 0) {
      return NextResponse.json({ error: "Warehouse not found" }, { status: 404 })
    }

    // Check if product exists
    const product = await db.select().from(products).where(eq(products.id, data.product_id))
    if (product.length === 0) {
      return NextResponse.json({ error: "Product not found" }, { status: 404 })
    }

    // Check if product already exists in warehouse
    const existingProduct = await db
      .select()
      .from(warehouseProducts)
      .where(
        and(eq(warehouseProducts.warehouse_id, data.warehouse_id), eq(warehouseProducts.product_id, data.product_id)),
      )

    if (existingProduct.length > 0) {
      // Update existing product quantity
      const updatedProduct = await db
        .update(warehouseProducts)
        .set({
          quantity: existingProduct[0].quantity + data.quantity,
          updated_at: new Date(),
        })
        .where(
          and(eq(warehouseProducts.warehouse_id, data.warehouse_id), eq(warehouseProducts.product_id, data.product_id)),
        )
        .returning()

      // Update warehouse used capacity
      await db
        .update(warehouses)
        .set({
          used: warehouse[0].used + data.quantity,
          updated_at: new Date(),
        })
        .where(eq(warehouses.id, data.warehouse_id))

      return NextResponse.json(updatedProduct[0])
    } else {
      // Create new warehouse product
      const newWarehouseProduct = await db
        .insert(warehouseProducts)
        .values({
          warehouse_id: data.warehouse_id,
          product_id: data.product_id,
          quantity: data.quantity,
          location: data.location || null,
        })
        .returning()

      // Update warehouse used capacity
      await db
        .update(warehouses)
        .set({
          used: warehouse[0].used + data.quantity,
          updated_at: new Date(),
        })
        .where(eq(warehouses.id, data.warehouse_id))

      return NextResponse.json(newWarehouseProduct[0])
    }
  } catch (error) {
    console.error("Error creating warehouse product:", error)
    return NextResponse.json({ error: "Failed to create warehouse product" }, { status: 500 })
  }
}

