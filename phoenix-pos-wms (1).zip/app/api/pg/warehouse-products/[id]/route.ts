import { NextResponse } from "next/server"
import { db } from "@/lib/db"
import { warehouseProducts, warehouses } from "@/lib/schema"
import { eq } from "drizzle-orm"

// GET warehouse product by ID
export async function GET(request: Request, { params }: { params: { id: string } }) {
  try {
    const id = Number.parseInt(params.id)

    if (isNaN(id)) {
      return NextResponse.json({ error: "Invalid ID" }, { status: 400 })
    }

    const warehouseProduct = await db.select().from(warehouseProducts).where(eq(warehouseProducts.id, id))

    if (warehouseProduct.length === 0) {
      return NextResponse.json({ error: "Warehouse product not found" }, { status: 404 })
    }

    return NextResponse.json(warehouseProduct[0])
  } catch (error) {
    (console.error("Error fetching warehouse product:", error)
    return NextResponse.json({ error: "Failed to fetch warehouse product" }, { status: 500 })
  }
}

// PUT update warehouse product
export async function PUT(request: Request, { params }: { params: { id: string } }) {
  try {
    const id = Number.parseInt(params.id)

    if (isNaN(id)) {
      return NextResponse.json({ error: "Invalid ID" }, { status: 400 })
    }

    const data = await request.json()

    // Get current warehouse product
    const currentProduct = await db.select().from(warehouseProducts).where(eq(warehouseProducts.id, id))

    if (currentProduct.length === 0) {
      return NextResponse.json({ error: "Warehouse product not found" }, { status: 404 })
    }

    // Calculate quantity difference
    const quantityDiff = data.quantity - currentProduct[0].quantity

    // Update the warehouse product
    const updatedProduct = await db
      .update(warehouseProducts)
      .set({
        quantity: data.quantity,
        location: data.location,
        updated_at: new Date(),
      })
      .where(eq(warehouseProducts.id, id))
      .returning()

    // Update warehouse used capacity
    if (quantityDiff !== 0) {
      const warehouse = await db.select().from(warehouses).where(eq(warehouses.id, currentProduct[0].warehouse_id))

      if (warehouse.length > 0) {
        await db
          .update(warehouses)
          .set({
            used: warehouse[0].used + quantityDiff,
            updated_at: new Date(),
          })
          .where(eq(warehouses.id, currentProduct[0].warehouse_id))
      }
    }

    return NextResponse.json(updatedProduct[0])
  } catch (error) {
    console.error("Error updating warehouse product:", error)
    return NextResponse.json({ error: "Failed to update warehouse product" }, { status: 500 })
  }
}

// DELETE warehouse product
export async function DELETE(request: Request, { params }: { params: { id: string } }) {
  try {
    const id = Number.parseInt(params.id)

    if (isNaN(id)) {
      return NextResponse.json({ error: "Invalid ID" }, { status: 400 })
    }

    // Get current warehouse product
    const currentProduct = await db.select().from(warehouseProducts).where(eq(warehouseProducts.id, id))

    if (currentProduct.length === 0) {
      return NextResponse.json({ error: "Warehouse product not found" }, { status: 404 })
    }

    // Delete the warehouse product
    const deletedProduct = await db.delete(warehouseProducts).where(eq(warehouseProducts.id, id)).returning()

    // Update warehouse used capacity
    const warehouse = await db.select().from(warehouses).where(eq(warehouses.id, currentProduct[0].warehouse_id))

    if (warehouse.length > 0) {
      await db
        .update(warehouses)
        .set({
          used: warehouse[0].used - currentProduct[0].quantity,
          updated_at: new Date(),
        })
        .where(eq(warehouses.id, currentProduct[0].warehouse_id))
    }

    return NextResponse.json({ message: "Warehouse product deleted successfully" })
  } catch (error) {
    console.error("Error deleting warehouse product:", error)
    return NextResponse.json({ error: "Failed to delete warehouse product" }, { status: 500 })
  }
}

