import { NextResponse } from "next/server"
import { executeQuery } from "@/lib/db"
import fs from "fs"
import { parse } from "csv-parse/sync"
import path from "path"

export async function POST(request: Request) {
  try {
    // Path to your CSV file
    const csvFilePath = path.resolve(process.cwd(), "data", "Customer Sheet C.csv")

    // Check if file exists
    if (!fs.existsSync(csvFilePath)) {
      return NextResponse.json({ error: "CSV file not found" }, { status: 404 })
    }

    // Read and parse the CSV file
    const fileContent = fs.readFileSync(csvFilePath, "utf8")
    const records = parse(fileContent, {
      columns: true,
      skip_empty_lines: true,
      trim: true,
    })

    let importCount = 0

    // Process each row
    for (const row of records) {
      // Map CSV columns to customer object
      const name = row[2] || ""
      if (!name) continue // Skip rows without a name

      const address = `${row[3] || ""} ${row[4] || ""}`.trim()
      const phone = row[11] || row[21] || ""
      const email = row[22] || ""
      const type = row[5] ? "wholesale" : "retail"
      const notes = row[23] || ""

      // Insert customer into PostgreSQL
      await executeQuery(
        `
        INSERT INTO customers (name, email, phone, address, type, notes, created_at, updated_at)
        VALUES ($1, $2, $3, $4, $5, $6, NOW(), NOW())
        `,
        [name, email, phone, address, type, notes],
      )

      importCount++
    }

    return NextResponse.json({
      success: true,
      message: `${importCount} customers imported successfully to PostgreSQL!`,
    })
  } catch (error) {
    console.error("Error importing customers to PostgreSQL:", error)
    return NextResponse.json({ error: "Failed to import customers" }, { status: 500 })
  }
}

