import { NextResponse } from "next/server"
import { setupUsers } from "@/scripts/create-users-pg"

export async function POST() {
  try {
    await setupUsers()
    return NextResponse.json({ success: true, message: "Users initialized successfully" })
  } catch (error) {
    console.error("Error initializing users:", error)
    return NextResponse.json(
      { success: false, message: "Failed to initialize users", error: String(error) },
      { status: 500 },
    )
  }
}

