import { NextResponse } from "next/server"
import { getSupabaseServerClient } from "@/lib/supabase"

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const warehouseId = searchParams.get("warehouseId")
    const productId = searchParams.get("productId")

    const supabase = getSupabaseServerClient()

    let query = supabase.from("warehouse_products").select(`
        *,
        warehouse:warehouses(id, name),
        product:products(id, name, sku, description)
      `)

    if (warehouseId) {
      query = query.eq("warehouse_id", warehouseId)
    }

    if (productId) {
      query = query.eq("product_id", productId)
    }

    const { data, error } = await query.order("created_at", { ascending: false })

    if (error) {
      return NextResponse.json({ error: error.message }, { status: 500 })
    }

    return NextResponse.json(data)
  } catch (error) {
    console.error("Error fetching inventory:", error)
    return NextResponse.json({ error: "Failed to fetch inventory" }, { status: 500 })
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json()
    const { warehouse_id, product_id, quantity, location } = body

    if (!warehouse_id || !product_id || quantity === undefined) {
      return NextResponse.json({ error: "Warehouse ID, Product ID, and quantity are required" }, { status: 400 })
    }

    const supabase = getSupabaseServerClient()

    // Check if the product already exists in the warehouse
    const { data: existingProduct } = await supabase
      .from("warehouse_products")
      .select("id, quantity")
      .eq("warehouse_id", warehouse_id)
      .eq("product_id", product_id)
      .maybeSingle()

    let result

    if (existingProduct) {
      // Update existing product quantity
      const newQuantity = existingProduct.quantity + quantity

      const { data, error } = await supabase
        .from("warehouse_products")
        .update({
          quantity: newQuantity,
          location: location || existingProduct.location,
          updated_at: new Date(),
        })
        .eq("id", existingProduct.id)
        .select()

      if (error) {
        return NextResponse.json({ error: error.message }, { status: 500 })
      }

      result = data[0]
    } else {
      // Add new product to warehouse
      const { data, error } = await supabase
        .from("warehouse_products")
        .insert({
          warehouse_id,
          product_id,
          quantity,
          location,
        })
        .select()

      if (error) {
        return NextResponse.json({ error: error.message }, { status: 500 })
      }

      result = data[0]
    }

    // Update the product's overall stock level
    await supabase.rpc("update_stock_level", {
      p_product_id: product_id,
      p_quantity: quantity,
    })

    // Update warehouse used capacity
    await supabase.rpc("update_warehouse_capacity", {
      p_warehouse_id: warehouse_id,
      p_quantity: quantity,
    })

    return NextResponse.json(result, { status: 201 })
  } catch (error) {
    console.error("Error updating inventory:", error)
    return NextResponse.json({ error: "Failed to update inventory" }, { status: 500 })
  }
}

export async function PUT(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const id = searchParams.get("id")

    if (!id) {
      return NextResponse.json({ error: "Inventory ID is required" }, { status: 400 })
    }

    const body = await request.json()
    const { quantity, location } = body

    if (quantity === undefined && !location) {
      return NextResponse.json({ error: "Either quantity or location must be provided" }, { status: 400 })
    }

    const supabase = getSupabaseServerClient()

    // Get current inventory record
    const { data: currentInventory, error: fetchError } = await supabase
      .from("warehouse_products")
      .select("quantity, warehouse_id, product_id")
      .eq("id", id)
      .single()

    if (fetchError) {
      return NextResponse.json({ error: fetchError.message }, { status: 500 })
    }

    // Calculate quantity difference if quantity is being updated
    const quantityDiff = quantity !== undefined ? quantity - currentInventory.quantity : 0

    // Update inventory record
    const updateData: any = { updated_at: new Date() }
    if (quantity !== undefined) updateData.quantity = quantity
    if (location) updateData.location = location

    const { data, error } = await supabase.from("warehouse_products").update(updateData).eq("id", id).select()

    if (error) {
      return NextResponse.json({ error: error.message }, { status: 500 })
    }

    // If quantity changed, update product stock level and warehouse capacity
    if (quantityDiff !== 0) {
      await supabase.rpc("update_stock_level", {
        p_product_id: currentInventory.product_id,
        p_quantity: quantityDiff,
      })

      await supabase.rpc("update_warehouse_capacity", {
        p_warehouse_id: currentInventory.warehouse_id,
        p_quantity: quantityDiff,
      })
    }

    return NextResponse.json(data[0])
  } catch (error) {
    console.error("Error updating inventory:", error)
    return NextResponse.json({ error: "Failed to update inventory" }, { status: 500 })
  }
}

export async function DELETE(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const id = searchParams.get("id")

    if (!id) {
      return NextResponse.json({ error: "Inventory ID is required" }, { status: 400 })
    }

    const supabase = getSupabaseServerClient()

    // Get current inventory record before deleting
    const { data: inventory, error: fetchError } = await supabase
      .from("warehouse_products")
      .select("quantity, warehouse_id, product_id")
      .eq("id", id)
      .single()

    if (fetchError) {
      return NextResponse.json({ error: fetchError.message }, { status: 500 })
    }

    // Delete the inventory record
    const { error } = await supabase.from("warehouse_products").delete().eq("id", id)

    if (error) {
      return NextResponse.json({ error: error.message }, { status: 500 })
    }

    // Update product stock level (decrease by the removed quantity)
    await supabase.rpc("update_stock_level", {
      p_product_id: inventory.product_id,
      p_quantity: -inventory.quantity,
    })

    // Update warehouse used capacity (decrease by the removed quantity)
    await supabase.rpc("update_warehouse_capacity", {
      p_warehouse_id: inventory.warehouse_id,
      p_quantity: -inventory.quantity,
    })

    return NextResponse.json({ message: "Inventory record deleted successfully" })
  } catch (error) {
    console.error("Error deleting inventory:", error)
    return NextResponse.json({ error: "Failed to delete inventory" }, { status: 500 })
  }
}

