import { NextResponse } from "next/server"
import { getWarehouseStock } from "@/lib/data-sources"

export async function GET() {
  try {
    const stock = await getWarehouseStock()
    return NextResponse.json(stock)
  } catch (error) {
    console.error("Error fetching warehouse stock:", error)
    return NextResponse.json({ error: "Failed to fetch warehouse stock" }, { status: 500 })
  }
}

