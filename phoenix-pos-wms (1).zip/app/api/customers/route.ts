import { NextResponse } from "next/server"
import { executeDbOperation, formatDocuments } from "@/lib/db"
import { COLLECTIONS } from "@/lib/schema"

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const page = Number.parseInt(searchParams.get("page") || "1")
    const limit = Number.parseInt(searchParams.get("limit") || "10")
    const sort = searchParams.get("sort") || "name"
    const order = searchParams.get("order") || "asc"

    const skip = (page - 1) * limit

    const customers = await executeDbOperation(async (db) => {
      const total = await db.collection(COLLECTIONS.CUSTOMERS).countDocuments()

      const sortDirection = order === "asc" ? 1 : -1
      const sortOptions: Record<string, number> = {}
      sortOptions[sort] = sortDirection

      const data = await db.collection(COLLECTIONS.CUSTOMERS).find().sort(sortOptions).skip(skip).limit(limit).toArray()

      const totalPages = Math.ceil(total / limit)

      return {
        data: formatDocuments(data),
        pagination: {
          total,
          page,
          limit,
          totalPages,
          hasNextPage: page < totalPages,
          hasPrevPage: page > 1,
        },
      }
    })

    return NextResponse.json(customers)
  } catch (error) {
    console.error("Error fetching customers:", error)
    return NextResponse.json({ error: "Failed to fetch customers" }, { status: 500 })
  }
}

export async function POST(request: Request) {
  try {
    const data = await request.json()

    // Validate required fields
    if (!data.name) {
      return NextResponse.json({ error: "Name is required" }, { status: 400 })
    }

    const newCustomer = await executeDbOperation(async (db) => {
      const result = await db.collection(COLLECTIONS.CUSTOMERS).insertOne({
        ...data,
        created_at: new Date(),
        updated_at: new Date(),
      })

      const insertedCustomer = await db.collection(COLLECTIONS.CUSTOMERS).findOne({ _id: result.insertedId })

      return formatDocuments([insertedCustomer])[0]
    })

    return NextResponse.json(newCustomer)
  } catch (error) {
    console.error("Error creating customer:", error)
    return NextResponse.json({ error: "Failed to create customer" }, { status: 500 })
  }
}

