import { NextResponse } from "next/server"
import { hash } from "bcrypt"
import clientPromise from "@/lib/mongodb"

export async function POST() {
  // This should only be accessible in development or with a special key
  if (process.env.NODE_ENV !== "development" && process.env.SEED_KEY !== process.env.SEED_SECRET) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  }

  try {
    const client = await clientPromise
    const db = client.db("phoenix_pos_wms")
    const usersCollection = db.collection("users")

    // Check if users already exist
    const existingUsers = await usersCollection.countDocuments()
    if (existingUsers > 0) {
      return NextResponse.json({ message: "Users already exist", count: existingUsers })
    }

    const saltRounds = 10
    const genericPassword = await hash("Phoenix2025", saltRounds)
    const adminPassword = await hash("Ruky0116*", saltRounds)

    // Create users array
    const users = []

    // 1. Master admin user
    users.push({
      username: "Angelus",
      password: adminPassword,
      name: "Angelus",
      email: "admin@phoenixcashandcarry.com",
      role: "admin",
      created_at: new Date(),
    })

    // 2. POS Users (1-30)
    for (let i = 1; i <= 30; i++) {
      users.push({
        username: `POS${i}`,
        password: genericPassword,
        name: `POS User ${i}`,
        email: `pos${i}@phoenixcashandcarry.com`,
        role: "pos",
        created_at: new Date(),
      })
    }

    // 3. Tele-sales Users (1-10)
    for (let i = 1; i <= 10; i++) {
      users.push({
        username: `Telesales${i}`,
        password: genericPassword,
        name: `Telesales User ${i}`,
        email: `telesales${i}@phoenixcashandcarry.com`,
        role: "telesales",
        created_at: new Date(),
      })
    }

    // 4. Generic Rep Users (1-5)
    for (let i = 1; i <= 5; i++) {
      users.push({
        username: `Rep${i}`,
        password: genericPassword,
        name: `Sales Rep ${i}`,
        email: `rep${i}@phoenixcashandcarry.com`,
        role: "salesrep",
        created_at: new Date(),
      })
    }

    // 5. Named Rep Users
    const namedReps = ["Lindo", "Suveer", "Sanele", "Wiseman", "Baskeer", "Innocent"]
    namedReps.forEach((name) => {
      users.push({
        username: name,
        password: genericPassword,
        name: name,
        email: `${name.toLowerCase()}@phoenixcashandcarry.com`,
        role: "salesrep",
        created_at: new Date(),
      })
    })

    // Insert all users
    const result = await usersCollection.insertMany(users)

    return NextResponse.json({
      success: true,
      message: `${result.insertedCount} users created successfully`,
      users: users.map((u) => ({ username: u.username, role: u.role })),
    })
  } catch (error) {
    console.error("Error creating users:", error)
    return NextResponse.json({ error: "Failed to create users" }, { status: 500 })
  }
}

