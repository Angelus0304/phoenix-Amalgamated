import { EnvDisplay } from "@/components/config/env-display"

export default function EnvironmentSettingsPage() {
  return (
    <div className="container mx-auto py-6">
      <h1 className="text-2xl font-bold mb-6">Environment Configuration</h1>
      <EnvDisplay />
    </div>
  )
}

