"use client"

import { useState } from "react"
import { DatabaseStatus } from "@/components/database/db-status"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Database, RefreshCw, Upload } from "lucide-react"
import { toast } from "sonner"

import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export default function DatabaseSettingsClientPage() {
  const [initializingDb, setInitializingDb] = useState(false)
  const [importingData, setImportingData] = useState(false)
  const [seedingData, setSeedingData] = useState(false)
  const [isLoading, setIsLoading] = useState(false)

  const handleInitializeDb = async () => {
    if (!confirm("This will create all necessary database tables. Continue?")) {
      return
    }

    setInitializingDb(true)
    try {
      const response = await fetch("/api/pg/init-db", {
        method: "POST",
      })

      if (!response.ok) {
        throw new Error("Failed to initialize database")
      }

      const data = await response.json()
      toast.success(data.message || "Database initialized successfully")
    } catch (error) {
      console.error("Error initializing database:", error)
      toast.error("Failed to initialize database")

      toast.error("Failed to initialize database")
    } finally {
      setInitializingDb(false)
    }
  }

  const handleImportCustomers = async () => {
    if (!confirm("This will import customers from the CSV file. Continue?")) {
      return
    }

    setImportingData(true)
    try {
      const response = await fetch("/api/pg/import-customers", {
        method: "POST",
      })

      if (!response.ok) {
        throw new Error("Failed to import customers")
      }

      const data = await response.json()
      toast.success(data.message || "Customers imported successfully")
    } catch (error) {
      console.error("Error importing customers:", error)
      toast.error("Failed to import customers")

      toast.error("Failed to import customers")
    } finally {
      setImportingData(false)
    }
  }

  const handleSeedData = async () => {
    if (!confirm("This will seed the database with sample data. Continue?")) {
      return
    }

    setSeedingData(true)
    try {
      const response = await fetch("/api/pg/seed-data", {
        method: "POST",

        method: "POST",
      })

      if (!response.ok) {
        throw new Error("Failed to seed database")
      }

      const data = await response.json()
      toast.success(data.message || "Database seeded successfully")
    } catch (error) {
      console.error("Error seeding database:", error)
      toast.error("Failed to seed database")

      console.error("Error seeding database:", error)
      toast.error("Failed to seed database")
    } finally {
      setSeedingData(false)
    }
  }

  return (
    <div className="container mx-auto py-6">
      <div className="mb-8">
        <h1 className="text-3xl font-bold">Database Settings</h1>
        <p className="text-muted-foreground">Manage database settings and operations</p>
      </div>

      <Tabs defaultValue="status" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="status">Status</TabsTrigger>
          <TabsTrigger value="operations">Operations</TabsTrigger>
          <TabsTrigger value="import">Import Data</TabsTrigger>
        </TabsList>

        <TabsContent value="status" className="mt-6">
          <DatabaseStatus />
        </TabsContent>

        <TabsContent value="operations" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle>Database Operations</CardTitle>
              <CardDescription>Perform database maintenance operations</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-sm text-muted-foreground">
                This section allows you to perform various database operations such as backup, restore, and maintenance.
              </p>

              <div className="flex flex-col gap-4 md:flex-row">
                <Button variant="outline" className="w-full" onClick={handleInitializeDb} disabled={initializingDb}>
                  <Database className="mr-2 h-4 w-4" />
                  {initializingDb ? "Initializing..." : "Initialize Tables"}
                </Button>
                <Button
                  onClick={async () => {
                    setIsLoading(true)
                    try {
                      const response = await fetch("/api/pg/init-users", {
                        method: "POST",
                      })
                      const data = await response.json()
                      if (data.success) {
                        toast({
                          title: "Success",
                          description: "Users initialized successfully",
                        })
                      } else {
                        toast({
                          title: "Error",
                          description: data.message || "Failed to initialize users",
                          variant: "destructive",
                        })
                      }
                    } catch (error) {
                      toast({
                        title: "Error",
                        description: "An error occurred while initializing users",
                        variant: "destructive",
                      })
                      console.error(error)
                    } finally {
                      setIsLoading(false)
                    }
                  }}
                  disabled={isLoading}
                  className="mb-4"
                  variant="outline"
                  className="w-full"
                >
                  Initialize Users
                </Button>
                <Button variant="outline" className="w-full" onClick={handleImportCustomers} disabled={importingData}>
                  <Upload className="mr-2 h-4 w-4" />
                  {importingData ? "Importing..." : "Import Customers"}
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="import" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle>Import Data</CardTitle>
              <CardDescription>Import data from external sources</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground mb-4">
                Import data from CSV files or other external sources.
              </p>

              <Button variant="outline" className="w-full" onClick={handleSeedData} disabled={seedingData}>
                <RefreshCw className="mr-2 h-4 w-4" />
                {seedingData ? "Seeding..." : "Seed Sample Data"}
              </Button>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}

