import type { Metadata } from "next"
import DatabaseSettingsClientPage from "./page.client"

export const metadata: Metadata = {
  title: "Database Settings",
  description: "Manage database settings and operations",
}

export default function DatabaseSettingsPage() {
  return <DatabaseSettingsClientPage />
}

