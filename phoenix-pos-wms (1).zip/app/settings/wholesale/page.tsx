import { WholesaleConfig } from "@/components/config/wholesale-config"

export default function WholesaleSettingsPage() {
  return (
    <div className="container mx-auto py-6">
      <h1 className="text-2xl font-bold mb-6">Wholesale & Business Settings</h1>
      <WholesaleConfig />
    </div>
  )
}

