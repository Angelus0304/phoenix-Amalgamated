import Image from "next/image"
import { LoginForm } from "@/components/auth/login-form"
import { LOGO_URL, COMPANY_NAME } from "@/lib/env"

export default function Home() {
  return (
    <div className="flex min-h-screen flex-col items-center justify-center bg-black">
      <div className="container flex flex-col items-center justify-center gap-6 px-4 py-16 ">
        <div className="flex flex-col items-center mb-8">
          <div className="mb-4 relative w-64 h-64 md:w-80 md:h-80">
            <Image
              src={LOGO_URL || "/placeholder.svg"}
              alt={`${COMPANY_NAME} Logo`}
              fill
              className="object-contain"
              priority
            />
          </div>
          <h1 className="text-3xl md:text-4xl font-bold text-white text-center phoenix-gradient bg-clip-text text-transparent">
            {COMPANY_NAME}
          </h1>
        </div>
        <p className="text-center text-lg text-gray-300 mb-6">
          Integrated Point of Sale and Warehouse Management System
        </p>
        <LoginForm />
      </div>
      <footer className="w-full py-4 text-center text-gray-500 text-sm">
        <p>© 2025 {COMPANY_NAME}. All rights reserved.</p>
        <p className="mt-1">Powered by Phoenix Online Amalgamated</p>
      </footer>
    </div>
  )

}

