"use client"

import { useState } from "react"
import { ArrowDownUp, CheckCircle, ClipboardList, Download, Filter, Search, Settings, User, Route } from "lucide-react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"

// Add imports at the top
import { isFeatureEnabled, isWarehouseEnabled } from "@/lib/feature-flags"

// Sample warehouse tasks
const tasks = [
  {
    id: "TASK-001",
    type: "Picking",
    orderId: "ORD-002",
    assignedTo: "John Smith",
    status: "In Progress",
    priority: "High",
    items: 3,
    progress: 33,
    dueDate: "2025-03-11",
  },
  {
    id: "TASK-002",
    type: "Packing",
    orderId: "ORD-003",
    assignedTo: "Emily Davis",
    status: "Pending",
    priority: "Medium",
    items: 2,
    progress: 0,
    dueDate: "2025-03-11",
  },
  {
    id: "TASK-003",
    type: "Shipping",
    orderId: "ORD-001",
    assignedTo: "Michael Wilson",
    status: "Completed",
    priority: "Medium",
    items: 3,
    progress: 100,
    dueDate: "2025-03-10",
  },
  {
    id: "TASK-004",
    type: "Receiving",
    orderId: "PO-001",
    assignedTo: "Sarah Brown",
    status: "In Progress",
    priority: "Low",
    items: 10,
    progress: 70,
    dueDate: "2025-03-12",
  },
  {
    id: "TASK-005",
    type: "Inventory Count",
    orderId: "N/A",
    assignedTo: "Robert Johnson",
    status: "Pending",
    priority: "High",
    items: 50,
    progress: 0,
    dueDate: "2025-03-13",
  },
]

// Sample warehouse zones
const zones = [
  {
    id: "ZONE-A",
    name: "Zone A",
    type: "Storage",
    capacity: 1000,
    used: 750,
    items: 120,
    status: "Active",
  },
  {
    id: "ZONE-B",
    name: "Zone B",
    type: "Picking",
    capacity: 500,
    used: 450,
    items: 80,
    status: "Active",
  },
  {
    id: "ZONE-C",
    name: "Zone C",
    type: "Packing",
    capacity: 300,
    used: 150,
    items: 30,
    status: "Active",
  },
  {
    id: "ZONE-D",
    name: "Zone D",
    type: "Shipping",
    capacity: 200,
    used: 180,
    items: 20,
    status: "Near Capacity",
  },
  {
    id: "ZONE-E",
    name: "Zone E",
    type: "Receiving",
    capacity: 400,
    used: 100,
    items: 15,
    status: "Active",
  },
]

export function WarehouseManagement() {
  const [searchTerm, setSearchTerm] = useState("")
  const [activeTab, setActiveTab] = useState("tasks")

  const filteredTasks = tasks.filter(
    (task) =>
      task.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
      task.orderId.toLowerCase().includes(searchTerm.toLowerCase()) ||
      task.assignedTo.toLowerCase().includes(searchTerm.toLowerCase()),
  )

  const filteredZones = zones.filter(
    (zone) =>
      zone.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
      zone.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      zone.type.toLowerCase().includes(searchTerm.toLowerCase()),
  )

  const getStatusColor = (status: string) => {
    switch (status) {
      case "Completed":
        return "default"
      case "In Progress":
        return "secondary"
      case "Pending":
        return "warning"
      default:
        return "default"
    }
  }

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "High":
        return "destructive"
      case "Medium":
        return "warning"
      case "Low":
        return "default"
      default:
        return "default"
    }
  }

  return (
    <div className="flex flex-col gap-4">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold tracking-tight">Warehouse Management</h1>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm">
            <Download className="mr-2 h-4 w-4" />
            Export
          </Button>
          <Button size="sm">
            <ClipboardList className="mr-2 h-4 w-4" />
            Create Task
          </Button>
          {isFeatureEnabled("picking_optimization") && (
            <Button size="sm">
              <Route className="mr-2 h-4 w-4" />
              Optimize Picking Routes
            </Button>
          )}
        </div>
      </div>

      <Tabs defaultValue="tasks" className="space-y-4" onValueChange={setActiveTab}>
        <TabsList>
          <TabsTrigger value="tasks">Tasks</TabsTrigger>
          <TabsTrigger value="zones">Warehouse Zones</TabsTrigger>
          <TabsTrigger value="staff">Staff</TabsTrigger>
        </TabsList>

        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2 w-full max-w-sm">
            <div className="relative w-full">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input
                type="search"
                placeholder={`Search ${activeTab}...`}
                className="w-full pl-8 bg-background"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline" size="icon">
                  <Filter className="h-4 w-4" />
                  <span className="sr-only">Filter</span>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuLabel>Filter By</DropdownMenuLabel>
                <DropdownMenuSeparator />
                {activeTab === "tasks" ? (
                  <>
                    <DropdownMenuItem>Type</DropdownMenuItem>
                    <DropdownMenuItem>Status</DropdownMenuItem>
                    <DropdownMenuItem>Priority</DropdownMenuItem>
                  </>
                ) : (
                  <>
                    <DropdownMenuItem>Type</DropdownMenuItem>
                    <DropdownMenuItem>Status</DropdownMenuItem>
                    <DropdownMenuItem>Capacity</DropdownMenuItem>
                  </>
                )}
              </DropdownMenuContent>
            </DropdownMenu>
            <Button variant="outline" size="icon">
              <Settings className="h-4 w-4" />
              <span className="sr-only">Settings</span>
            </Button>
            <Button variant="outline" size="icon">
              <ArrowDownUp className="h-4 w-4" />
              <span className="sr-only">Sort</span>
            </Button>
          </div>
        </div>

        <TabsContent value="tasks" className="space-y-4">
          <Card>
            <CardContent className="p-0">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Task ID</TableHead>
                    <TableHead>Type</TableHead>
                    <TableHead>Order/PO</TableHead>
                    <TableHead>Assigned To</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Priority</TableHead>
                    <TableHead>Progress</TableHead>
                    <TableHead>Due Date</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredTasks.map((task) => (
                    <TableRow key={task.id}>
                      <TableCell className="font-medium">{task.id}</TableCell>
                      <TableCell>{task.type}</TableCell>
                      <TableCell>{task.orderId}</TableCell>
                      <TableCell>{task.assignedTo}</TableCell>
                      <TableCell>
                        <Badge variant={getStatusColor(task.status) as any}>{task.status}</Badge>
                      </TableCell>
                      <TableCell>
                        <Badge variant={getPriorityColor(task.priority) as any}>{task.priority}</Badge>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <Progress value={task.progress} className="h-2 w-[60px]" />
                          <span className="text-xs">{task.progress}%</span>
                        </div>
                      </TableCell>
                      <TableCell>{task.dueDate}</TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <Button variant="ghost" size="icon">
                            <CheckCircle className="h-4 w-4" />
                            <span className="sr-only">Complete task</span>
                          </Button>
                          <Button variant="ghost" size="icon">
                            <User className="h-4 w-4" />
                            <span className="sr-only">Assign task</span>
                          </Button>
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" size="icon">
                                <svg
                                  xmlns="http://www.w3.org/2000/svg"
                                  width="24"
                                  height="24"
                                  viewBox="0 0 24 24"
                                  fill="none"
                                  stroke="currentColor"
                                  strokeWidth="2"
                                  strokeLinecap="round"
                                  strokeLinejoin="round"
                                  className="h-4 w-4"
                                >
                                  <circle cx="12" cy="12" r="1" />
                                  <circle cx="12" cy="5" r="1" />
                                  <circle cx="12" cy="19" r="1" />
                                </svg>
                                <span className="sr-only">More options</span>
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                              <DropdownMenuItem>Edit</DropdownMenuItem>
                              <DropdownMenuItem>View Details</DropdownMenuItem>
                              <DropdownMenuSeparator />
                              <DropdownMenuItem className="text-red-600">Cancel</DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="zones" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {filteredZones
              .filter((zone) => {
                // Only show enabled warehouses
                if (zone.id === "ZONE-A" && !isWarehouseEnabled(1)) return false
                if (zone.id === "ZONE-B" && !isWarehouseEnabled(2)) return false
                if (zone.id === "ZONE-C" && !isWarehouseEnabled(3)) return false
                if (zone.id === "ZONE-D" && !isWarehouseEnabled(4)) return false
                return true
              })
              .map((zone) => (
                <Card key={zone.id}>
                  <CardHeader className="pb-2">
                    <div className="flex items-center justify-between">
                      <CardTitle>{zone.name}</CardTitle>
                      <Badge>{zone.status}</Badge>
                    </div>
                    <CardDescription>{zone.type}</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="space-y-2">
                        <div className="flex items-center justify-between text-sm">
                          <span>Capacity Usage</span>
                          <span>
                            {zone.used} / {zone.capacity}
                          </span>
                        </div>
                        <Progress value={(zone.used / zone.capacity) * 100} className="h-2" />
                      </div>
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="text-sm text-muted-foreground">Items</p>
                          <p className="text-lg font-medium">{zone.items}</p>
                        </div>
                        <div>
                          <p className="text-sm text-muted-foreground">Utilization</p>
                          <p className="text-lg font-medium">{Math.round((zone.used / zone.capacity) * 100)}%</p>
                        </div>
                        <Button variant="outline" size="sm">
                          View
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
          </div>
        </TabsContent>

        <TabsContent value="staff" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Warehouse Staff</CardTitle>
              <CardDescription>Manage warehouse staff and assignments</CardDescription>
            </CardHeader>
            <CardContent>
              <p>Staff management content coming soon...</p>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}

