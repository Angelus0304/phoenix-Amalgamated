"use client"

import { useState, type FormEvent } from "react"
import { useRouter } from "next/navigation"
import { Eye, EyeOff, LogIn, Fingerprint } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { COMPANY_NAME } from "@/lib/env"
import { isFeatureEnabled } from "@/lib/feature-flags"

export function LoginForm() {
  const [showPassword, setShowPassword] = useState(false)
  const [isLoading, setIsLoading] = useState(false)
  const router = useRouter()

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault()
    setIsLoading(true)

    setTimeout(() => {
      setIsLoading(false)

      if (isFeatureEnabled("multi_factor_auth")) {
        alert("Multi-factor authentication required. Check your phone for a verification code.")
        setTimeout(() => router.push("/dashboard"), 1500)
      } else {
        router.push("/dashboard")
      }
    }, 1500)
  }

  return (
    <Card className="w-full max-w-md bg-card">
      <CardHeader className="space-y-1">
        <CardTitle className="text-2xl text-center text-white">Sign in</CardTitle>
        <CardDescription className="text-center text-gray-400">
          Enter your credentials to access your account
        </CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit}>
          <div className="grid gap-4">
            <div className="grid gap-2">
              <Label htmlFor="email" className="text-white">
                Email
              </Label>
              <Input
                id="email"
                type="email"
                placeholder="name@example.com"
                required
                disabled={isLoading}
                className="bg-secondary text-white"
              />
            </div>
            <div className="grid gap-2">
              <div className="flex items-center justify-between">
                <Label htmlFor="password" className="text-white">
                  Password
                </Label>
                <a href="#" className="text-sm text-phoenix-red hover:text-phoenix-orange">
                  Forgot password?
                </a>
              </div>
              <div className="relative">
                <Input
                  id="password"
                  type={showPassword ? "text" : "password"}
                  placeholder="••••••••"
                  required
                  disabled={isLoading}
                  className="bg-secondary text-white"
                />
                <Button
                  type="button"
                  variant="ghost"
                  size="icon"
                  className="absolute right-0 top-0 h-full px-3 py-2 hover:bg-transparent text-white"
                  onClick={() => setShowPassword(!showPassword)}
                  disabled={isLoading}
                >
                  {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                  <span className="sr-only">{showPassword ? "Hide password" : "Show password"}</span>
                </Button>
              </div>
            </div>
            {isFeatureEnabled("biometric_login") && (
              <Button type="button" className="w-full" variant="outline">
                <Fingerprint className="mr-2 h-4 w-4" />
                Login with Biometrics
              </Button>
            )}
            <Button type="submit" className="w-full phoenix-gradient" disabled={isLoading}>
              {isLoading ? (
                <div className="flex items-center gap-2">
                  <div
                    className="h-4 w-4 animate-spin rounded-full border-2 border-current border-t-transparent"
                    role="status"
                  />
                  <span>Signing in...</span>
                </div>
              ) : (
                <div className="flex items-center gap-2">
                  <LogIn className="h-4 w-4" />
                  <span>Sign in</span>
                </div>
              )}
            </Button>
          </div>
        </form>
      </CardContent>
      <CardFooter className="flex flex-col">
        <p className="mt-2 text-xs text-center text-gray-500">&copy; 2025 {COMPANY_NAME}. All rights reserved.</p>
      </CardFooter>
    </Card>
  )
}

