"use client"

import type React from "react"

import { useState } from "react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import {
  BarChart3,
  Box,
  ClipboardList,
  CreditCard,
  Home,
  Package,
  Settings,
  ShoppingCart,
  Truck,
  Users,
  Warehouse,
  Store,
  FileText,
  UserCircle,
  BarChart,
  ChevronDown,
  ChevronRight,
  Database,
} from "lucide-react"
import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible"
import { COMPANY_NAME } from "@/lib/env"

interface SidebarNavItem {
  title: string
  href: string
  icon: React.ReactNode
  submenu?: SidebarNavItem[]
}

export function DashboardSidebar() {
  const pathname = usePathname()
  const [openGroups, setOpenGroups] = useState<Record<string, boolean>>({
    settings: pathname.includes("/settings"),
    inventory: pathname.includes("/inventory"),
    sales: pathname.includes("/sales"),
    customers: pathname.includes("/customers"),
  })

  const toggleGroup = (group: string) => {
    setOpenGroups((prev) => ({
      ...prev,
      [group]: !prev[group],
    }))
  }

  const navItems: SidebarNavItem[] = [
    {
      title: "Dashboard",
      href: "/dashboard",
      icon: <Home className="h-5 w-5" />,
    },
    {
      title: "Inventory",
      href: "#",
      icon: <Package className="h-5 w-5" />,
      submenu: [
        {
          title: "Products",
          href: "/inventory/products",
          icon: <Box className="h-4 w-4" />,
        },
        {
          title: "Categories",
          href: "/inventory/categories",
          icon: <ClipboardList className="h-4 w-4" />,
        },
        {
          title: "Stock Levels",
          href: "/inventory/stock",
          icon: <BarChart3 className="h-4 w-4" />,
        },
      ],
    },
    {
      title: "Warehouse",
      href: "/warehouse",
      icon: <Warehouse className="h-5 w-5" />,
    },
    {
      title: "Sales",
      href: "#",
      icon: <ShoppingCart className="h-5 w-5" />,
      submenu: [
        {
          title: "Point of Sale",
          href: "/sales/pos",
          icon: <CreditCard className="h-4 w-4" />,
        },
        {
          title: "Orders",
          href: "/sales/orders",
          icon: <ClipboardList className="h-4 w-4" />,
        },
        {
          title: "Invoices",
          href: "/sales/invoices",
          icon: <FileText className="h-4 w-4" />,
        },
        {
          title: "Sales Reps",
          href: "/sales/reps",
          icon: <UserCircle className="h-4 w-4" />,
        },
      ],
    },
    {
      title: "Customers",
      href: "#",
      icon: <Users className="h-5 w-5" />,
      submenu: [
        {
          title: "All Customers",
          href: "/customers",
          icon: <Users className="h-4 w-4" />,
        },
        {
          title: "Wholesale",
          href: "/customers/wholesale",
          icon: <Store className="h-4 w-4" />,
        },
        {
          title: "Stokvel Groups",
          href: "/customers/stokvel",
          icon: <Users className="h-4 w-4" />,
        },
      ],
    },
    {
      title: "Shipping",
      href: "/shipping",
      icon: <Truck className="h-5 w-5" />,
    },
    {
      title: "Reports",
      href: "/reports",
      icon: <BarChart className="h-5 w-5" />,
    },
    {
      title: "Settings",
      href: "#",
      icon: <Settings className="h-5 w-5" />,
      submenu: [
        {
          title: "General",
          href: "/settings/general",
          icon: <Settings className="h-4 w-4" />,
        },
        {
          title: "Wholesale",
          href: "/settings/wholesale",
          icon: <Store className="h-4 w-4" />,
        },
        {
          title: "Users",
          href: "/settings/users",
          icon: <Users className="h-4 w-4" />,
        },
        {
          title: "Environment",
          href: "/settings/environment",
          icon: <ClipboardList className="h-4 w-4" />,
        },
        {
          title: "Database",
          href: "/settings/database",
          icon: <Database className="h-4 w-4" />,
        },
      ],
    },
  ]

  return (
    <div className="hidden border-r bg-card h-screen md:flex md:w-64 md:flex-col">
      <div className="flex flex-col h-full">
        <div className="flex h-14 items-center border-b px-4">
          <Link href="/dashboard" className="flex items-center gap-2 font-semibold">
            <Warehouse className="h-6 w-6" />
            <span className="text-sm font-bold">{COMPANY_NAME}</span>
          </Link>
        </div>
        <ScrollArea className="flex-1 py-2">
          <nav className="flex flex-col gap-1 px-2">
            {navItems.map((item, index) =>
              item.submenu ? (
                <Collapsible
                  key={index}
                  open={openGroups[item.title.toLowerCase()]}
                  onOpenChange={() => toggleGroup(item.title.toLowerCase())}
                  className="w-full"
                >
                  <CollapsibleTrigger asChild>
                    <Button
                      variant="ghost"
                      className={cn("w-full justify-between font-normal", pathname.includes(item.href) && "bg-accent")}
                    >
                      <div className="flex items-center">
                        {item.icon}
                        <span className="ml-2">{item.title}</span>
                      </div>
                      {openGroups[item.title.toLowerCase()] ? (
                        <ChevronDown className="h-4 w-4" />
                      ) : (
                        <ChevronRight className="h-4 w-4" />
                      )}
                    </Button>
                  </CollapsibleTrigger>
                  <CollapsibleContent className="pl-4 pt-1">
                    {item.submenu.map((subItem, subIndex) => (
                      <Link key={subIndex} href={subItem.href}>
                        <Button
                          variant="ghost"
                          className={cn(
                            "w-full justify-start font-normal",
                            pathname === subItem.href && "bg-accent text-accent-foreground",
                          )}
                        >
                          {subItem.icon}
                          <span className="ml-2">{subItem.title}</span>
                        </Button>
                      </Link>
                    ))}
                  </CollapsibleContent>
                </Collapsible>
              ) : (
                <Link key={index} href={item.href}>
                  <Button
                    variant="ghost"
                    className={cn(
                      "w-full justify-start font-normal",
                      pathname === item.href && "bg-accent text-accent-foreground",
                    )}
                  >
                    {item.icon}
                    <span className="ml-2">{item.title}</span>
                  </Button>
                </Link>
              ),
            )}
          </nav>
        </ScrollArea>
        <div className="border-t p-4">
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <div className="h-2 w-2 rounded-full bg-green-500" />
            <span>System Online</span>
          </div>
        </div>
      </div>
    </div>
  )
}

