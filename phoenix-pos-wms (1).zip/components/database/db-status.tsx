"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { AlertCircle, CheckCircle, Database, RefreshCw } from "lucide-react"
import { useToast } from "@/hooks/use-toast"

export function DatabaseStatus() {
  const [status, setStatus] = useState<{
    connected: boolean
    timestamp?: string
    error?: any
  } | null>(null)
  const [loading, setLoading] = useState(true)
  const [initializing, setInitializing] = useState(false)
  const { toast } = useToast()

  const checkStatus = async () => {
    setLoading(true)
    try {
      const response = await fetch("/api/db-status")
      const data = await response.json()
      setStatus(data)
    } catch (error) {
      console.error("Error checking database status:", error)
      setStatus({ connected: false, error: error.message })
    } finally {
      setLoading(false)
    }
  }

  const initializeDatabase = async () => {
    setInitializing(true)
    try {
      const response = await fetch("/api/init-db", {
        method: "POST",
      })

      const data = await response.json()

      if (response.ok) {
        toast({
          title: "Database Initialized",
          description: data.message,
          variant: "default",
        })

        // Refresh status
        checkStatus()
      } else {
        toast({
          title: "Initialization Failed",
          description: data.error || "An error occurred during database initialization",
          variant: "destructive",
        })
      }
    } catch (error) {
      console.error("Error initializing database:", error)
      toast({
        title: "Initialization Failed",
        description: "An error occurred during database initialization",
        variant: "destructive",
      })
    } finally {
      setInitializing(false)
    }
  }

  useEffect(() => {
    checkStatus()
  }, [])

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Database className="h-5 w-5" />
          Database Status
        </CardTitle>
        <CardDescription>MongoDB Connection Status</CardDescription>
      </CardHeader>
      <CardContent>
        {loading ? (
          <div className="flex items-center justify-center py-4">
            <RefreshCw className="h-6 w-6 animate-spin text-muted-foreground" />
          </div>
        ) : (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <span className="font-medium">Connection:</span>
              {status?.connected ? (
                <Badge
                  variant="outline"
                  className="bg-green-50 text-green-700 border-green-200 flex items-center gap-1"
                >
                  <CheckCircle className="h-3.5 w-3.5" />
                  Connected
                </Badge>
              ) : (
                <Badge variant="outline" className="bg-red-50 text-red-700 border-red-200 flex items-center gap-1">
                  <AlertCircle className="h-3.5 w-3.5" />
                  Disconnected
                </Badge>
              )}
            </div>

            {status?.timestamp && (
              <div className="flex items-center justify-between">
                <span className="font-medium">Last Checked:</span>
                <span className="text-sm text-muted-foreground">{new Date(status.timestamp).toLocaleString()}</span>
              </div>
            )}

            {status?.error && (
              <div className="mt-2 text-sm text-red-600 bg-red-50 p-2 rounded border border-red-100">
                <p className="font-semibold">Error:</p>
                <p className="font-mono text-xs break-all">{JSON.stringify(status.error)}</p>
              </div>
            )}
          </div>
        )}
      </CardContent>
      <CardFooter className="flex justify-between">
        <Button variant="outline" onClick={checkStatus} disabled={loading}>
          <RefreshCw className={`mr-2 h-4 w-4 ${loading ? "animate-spin" : ""}`} />
          Refresh
        </Button>
        <Button onClick={initializeDatabase} disabled={initializing || loading}>
          {initializing ? (
            <>
              <RefreshCw className="mr-2 h-4 w-4 animate-spin" />
              Initializing...
            </>
          ) : (
            <>Initialize Database</>
          )}
        </Button>
      </CardFooter>
    </Card>
  )
}

