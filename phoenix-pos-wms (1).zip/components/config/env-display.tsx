"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import * as env from "@/lib/env"

export function EnvDisplay() {
  // Group environment variables by category
  const categories = {
    Application: [
      { key: "APP_NAME", value: env.APP_NAME },
      { key: "APP_URL", value: env.APP_URL },
      { key: "API_URL", value: env.API_URL },
      { key: "COMPANY_NAME", value: env.COMPANY_NAME },
      { key: "SUPPORT_EMAIL", value: env.SUPPORT_EMAIL },
      { key: "SUPPORT_PHONE", value: env.SUPPORT_PHONE },
    ],
    Wholesale: [
      { key: "WHOLESALE_PRICING", value: String(env.WHOLESALE_PRICING) },
      { key: "WHOLESALE_MIN_QUANTITY", value: String(env.WHOLESALE_MIN_QUANTITY) },
      { key: "WHOLESALE_DISCOUNT", value: env.WHOLESALE_DISCOUNT },
      { key: "WHOLESALE_CREDIT_LIMIT", value: String(env.WHOLESALE_CREDIT_LIMIT) },
      { key: "WHOLESALE_INVOICE_TERMS", value: env.WHOLESALE_INVOICE_TERMS },
      { key: "WHOLESALE_TAX_EXEMPTION", value: String(env.WHOLESALE_TAX_EXEMPTION) },
      { key: "WHOLESALE_ORDER_APPROVAL", value: String(env.WHOLESALE_ORDER_APPROVAL) },
      { key: "WHOLESALE_STOCK_ALLOCATION", value: env.WHOLESALE_STOCK_ALLOCATION },
      { key: "WHOLESALE_RETURNS_POLICY", value: env.WHOLESALE_RETURNS_POLICY },
      { key: "WHOLESALE_PAYMENT_GATEWAY", value: env.WHOLESALE_PAYMENT_GATEWAY },
    ],
    "Sales Rep": [
      { key: "SALESREP_ASSIGN", value: env.SALESREP_ASSIGN },
      { key: "SALESREP_ROUTE_LIST", value: env.SALESREP_ROUTE_LIST },
      { key: "SALESREP_GEOTRACKING", value: String(env.SALESREP_GEOTRACKING) },
      { key: "SALESREP_TARGETS", value: String(env.SALESREP_TARGETS) },
      { key: "SALESREP_INCENTIVES", value: env.SALESREP_INCENTIVES },
      { key: "SALESREP_LIVE_QUOTING", value: String(env.SALESREP_LIVE_QUOTING) },
      { key: "SALESREP_ORDER_PLACEMENT", value: String(env.SALESREP_ORDER_PLACEMENT) },
      { key: "SALESREP_CUSTOMER_NOTES", value: env.SALESREP_CUSTOMER_NOTES },
      { key: "SALESREP_PERFORMANCE_ANALYTICS", value: String(env.SALESREP_PERFORMANCE_ANALYTICS) },
    ],
    Stokvel: [
      { key: "STOKVEL_GROUP_MANAGEMENT", value: env.STOKVEL_GROUP_MANAGEMENT },
      { key: "STOKVEL_MEMBER_LIST", value: env.STOKVEL_MEMBER_LIST },
      { key: "STOKVEL_CONTRIBUTION_TRACKING", value: String(env.STOKVEL_CONTRIBUTION_TRACKING) },
      { key: "STOKVEL_PAYMENT_SCHEDULE", value: env.STOKVEL_PAYMENT_SCHEDULE },
      { key: "STOKVEL_BULK_DISCOUNT", value: env.STOKVEL_BULK_DISCOUNT },
      { key: "STOKVEL_ORDER_SPLITTING", value: env.STOKVEL_ORDER_SPLITTING },
      { key: "STOKVEL_COLLECTION_SCHEDULE", value: env.STOKVEL_COLLECTION_SCHEDULE },
      { key: "STOKVEL_LEADER_APPROVAL", value: String(env.STOKVEL_LEADER_APPROVAL) },
    ],
    "Bulk Order": [
      { key: "BULK_ORDER_DISCOUNT", value: env.BULK_ORDER_DISCOUNT },
      { key: "BULK_ORDER_SHIPPING_OPTIONS", value: env.BULK_ORDER_SHIPPING_OPTIONS.join(", ") },
      { key: "BULK_ORDER_WAREHOUSE_ASSIGNMENT", value: env.BULK_ORDER_WAREHOUSE_ASSIGNMENT },
      { key: "BULK_ORDER_QUOTE_REQUEST", value: env.BULK_ORDER_QUOTE_REQUEST },
      { key: "BULK_ORDER_APPROVAL_PROCESS", value: env.BULK_ORDER_APPROVAL_PROCESS },
      { key: "BULK_ORDER_PAYMENT_TERMS", value: env.BULK_ORDER_PAYMENT_TERMS },
      { key: "BULK_ORDER_STOCK_RESERVATION", value: env.BULK_ORDER_STOCK_RESERVATION },
    ],
    Customer: [
      { key: "CUSTOMER_COMPANY_NAME", value: env.CUSTOMER_COMPANY_NAME },
      { key: "CUSTOMER_BUSINESS_TYPE", value: env.CUSTOMER_BUSINESS_TYPE },
      { key: "CUSTOMER_BULK_BUYING_STATUS", value: env.CUSTOMER_BULK_BUYING_STATUS },
      { key: "CUSTOMER_PURCHASE_HISTORY", value: env.CUSTOMER_PURCHASE_HISTORY },
      { key: "CUSTOMER_LOYALTY_TIER", value: env.CUSTOMER_LOYALTY_TIER },
      { key: "CUSTOMER_SALES_REP_ASSIGNMENT", value: env.CUSTOMER_SALES_REP_ASSIGNMENT },
      { key: "CUSTOMER_CREDIT_STATUS", value: env.CUSTOMER_CREDIT_STATUS },
      { key: "CUSTOMER_ACCOUNT_AGE", value: String(env.CUSTOMER_ACCOUNT_AGE) },
      { key: "CUSTOMER_DISCOUNT_LEVEL", value: env.CUSTOMER_DISCOUNT_LEVEL },
      { key: "CUSTOMER_ORDER_FREQUENCY", value: env.CUSTOMER_ORDER_FREQUENCY },
    ],
    Warehouse: [
      { key: "WAREHOUSE_1_STOCK_LEVEL", value: String(env.WAREHOUSE_1_STOCK_LEVEL) },
      { key: "WAREHOUSE_2_STOCK_LEVEL", value: String(env.WAREHOUSE_2_STOCK_LEVEL) },
      { key: "WAREHOUSE_3_STOCK_LEVEL", value: String(env.WAREHOUSE_3_STOCK_LEVEL) },
      { key: "WAREHOUSE_4_STOCK_LEVEL", value: String(env.WAREHOUSE_4_STOCK_LEVEL) },
      { key: "RECEIVING_PORT_1_STATUS", value: env.RECEIVING_PORT_1_STATUS },
      { key: "RECEIVING_PORT_2_STATUS", value: env.RECEIVING_PORT_2_STATUS },
      { key: "RECEIVING_PORT_3_STATUS", value: env.RECEIVING_PORT_3_STATUS },
      { key: "GRV_CAPTURE_SYSTEM", value: env.GRV_CAPTURE_SYSTEM },
      { key: "WAREHOUSE_AUTO_ALLOCATION", value: String(env.WAREHOUSE_AUTO_ALLOCATION) },
    ],
    "E-commerce": [
      { key: "ECOMM_STOCK_SYNC", value: String(env.ECOMM_STOCK_SYNC) },
      { key: "ECOMM_PRICE_SYNC", value: String(env.ECOMM_PRICE_SYNC) },
      { key: "ECOMM_ABANDONED_CART_RECOVERY", value: env.ECOMM_ABANDONED_CART_RECOVERY },
      { key: "ECOMM_WHOLESALE_ACCOUNT", value: env.ECOMM_WHOLESALE_ACCOUNT },
      { key: "ECOMM_DYNAMIC_DISCOUNTING", value: String(env.ECOMM_DYNAMIC_DISCOUNTING) },
      { key: "ECOMM_AUTO_UPSELL", value: env.ECOMM_AUTO_UPSELL },
      { key: "ECOMM_CROSS_SHIPPING_OPTIONS", value: env.ECOMM_CROSS_SHIPPING_OPTIONS.join(", ") },
    ],
    System: [
      { key: "IS_PRODUCTION", value: String(env.IS_PRODUCTION) },
      { key: "IS_DEVELOPMENT", value: String(env.IS_DEVELOPMENT) },
      { key: "IS_TEST", value: String(env.IS_TEST) },
      { key: "PORT", value: String(env.PORT) },
      { key: "P", value: env.P },
    ],
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Environment Variables</CardTitle>
        <CardDescription>Current configuration settings for the Phoenix POS/WMS system</CardDescription>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="Application">
          <TabsList className="grid grid-cols-4 mb-4">
            {Object.keys(categories).map((category) => (
              <TabsTrigger key={category} value={category}>
                {category}
              </TabsTrigger>
            ))}
          </TabsList>

          {Object.entries(categories).map(([category, variables]) => (
            <TabsContent key={category} value={category}>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Variable</TableHead>
                    <TableHead>Value</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {variables.map((variable) => (
                    <TableRow key={variable.key}>
                      <TableCell className="font-medium">{variable.key}</TableCell>
                      <TableCell>
                        {variable.value === "true" || variable.value === "false" ? (
                          <Badge variant={variable.value === "true" ? "default" : "secondary"}>{variable.value}</Badge>
                        ) : (
                          variable.value
                        )}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </TabsContent>
          ))}
        </Tabs>
      </CardContent>
    </Card>
  )
}

