"use client"

import type React from "react"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Button } from "@/components/ui/button"
import { Switch } from "@/components/ui/switch"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Separator } from "@/components/ui/separator"
import { Badge } from "@/components/ui/badge"
import { Save, RefreshCw } from "lucide-react"
import {
  WHOLESALE_PRICING,
  WHOLESALE_MIN_QUANTITY,
  WHOLESALE_DISCOUNT,
  WHOLESALE_CREDIT_LIMIT,
  WHOLESALE_INVOICE_TERMS,
  WHOLESALE_TAX_EXEMPTION,
  WHOLESALE_ORDER_APPROVAL,
  WHOLESALE_STOCK_ALLOCATION,
  WHOLESALE_RETURNS_POLICY,
  WHOLESALE_PAYMENT_GATEWAY,
  SALESREP_ASSIGN,
  SALESREP_TARGETS,
  BULK_ORDER_DISCOUNT,
  BULK_ORDER_PAYMENT_TERMS,
  STOKVEL_BULK_DISCOUNT,
  STOKVEL_PAYMENT_SCHEDULE,
} from "@/lib/env"

export function WholesaleConfig() {
  // State for wholesale settings
  const [wholesalePricing, setWholesalePricing] = useState(WHOLESALE_PRICING)
  const [minQuantity, setMinQuantity] = useState(WHOLESALE_MIN_QUANTITY)
  const [discount, setDiscount] = useState(WHOLESALE_DISCOUNT)
  const [creditLimit, setCreditLimit] = useState(WHOLESALE_CREDIT_LIMIT)
  const [invoiceTerms, setInvoiceTerms] = useState(WHOLESALE_INVOICE_TERMS)
  const [taxExemption, setTaxExemption] = useState(WHOLESALE_TAX_EXEMPTION)
  const [orderApproval, setOrderApproval] = useState(WHOLESALE_ORDER_APPROVAL)
  const [stockAllocation, setStockAllocation] = useState(WHOLESALE_STOCK_ALLOCATION)
  const [returnsPolicy, setReturnsPolicy] = useState(WHOLESALE_RETURNS_POLICY)
  const [paymentGateway, setPaymentGateway] = useState(WHOLESALE_PAYMENT_GATEWAY)

  // State for sales rep settings
  const [salesRepAssign, setSalesRepAssign] = useState(SALESREP_ASSIGN)
  const [salesRepTargets, setSalesRepTargets] = useState(SALESREP_TARGETS)

  // State for bulk order settings
  const [bulkOrderDiscount, setBulkOrderDiscount] = useState(BULK_ORDER_DISCOUNT)
  const [bulkOrderPaymentTerms, setBulkOrderPaymentTerms] = useState(BULK_ORDER_PAYMENT_TERMS)

  // State for stokvel settings
  const [stokvelBulkDiscount, setStokvelBulkDiscount] = useState(STOKVEL_BULK_DISCOUNT)
  const [stokvelPaymentSchedule, setStokvelPaymentSchedule] = useState(STOKVEL_PAYMENT_SCHEDULE)

  // Handle form submission
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    // In a real application, this would save to the server
    alert("Settings saved successfully!")
  }

  return (
    <form onSubmit={handleSubmit}>
      <Tabs defaultValue="wholesale" className="w-full">
        <TabsList className="grid grid-cols-4 mb-4">
          <TabsTrigger value="wholesale">Wholesale</TabsTrigger>
          <TabsTrigger value="salesrep">Sales Rep</TabsTrigger>
          <TabsTrigger value="bulkorder">Bulk Orders</TabsTrigger>
          <TabsTrigger value="stokvel">Stokvel</TabsTrigger>
        </TabsList>

        <TabsContent value="wholesale">
          <Card>
            <CardHeader>
              <CardTitle>Wholesale Configuration</CardTitle>
              <CardDescription>Manage wholesale pricing and policies for business customers</CardDescription>
              <Badge variant={wholesalePricing ? "default" : "outline"} className="ml-auto">
                {wholesalePricing ? "Enabled" : "Disabled"}
              </Badge>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <Label htmlFor="wholesale-pricing" className="flex flex-col">
                  <span>Enable Wholesale Pricing</span>
                  <span className="text-sm text-muted-foreground">Allow special pricing for wholesale customers</span>
                </Label>
                <Switch id="wholesale-pricing" checked={wholesalePricing} onCheckedChange={setWholesalePricing} />
              </div>

              <Separator />

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="min-quantity">Minimum Order Quantity</Label>
                  <Input
                    id="min-quantity"
                    type="number"
                    value={minQuantity}
                    onChange={(e) => setMinQuantity(Number(e.target.value))}
                    min={1}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="discount">Default Discount</Label>
                  <Input id="discount" value={discount} onChange={(e) => setDiscount(e.target.value)} />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="credit-limit">Default Credit Limit</Label>
                  <Input
                    id="credit-limit"
                    type="number"
                    value={creditLimit}
                    onChange={(e) => setCreditLimit(Number(e.target.value))}
                    min={0}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="invoice-terms">Invoice Terms</Label>
                  <Select value={invoiceTerms} onValueChange={setInvoiceTerms}>
                    <SelectTrigger id="invoice-terms">
                      <SelectValue placeholder="Select terms" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Net15">Net 15</SelectItem>
                      <SelectItem value="Net30">Net 30</SelectItem>
                      <SelectItem value="Net60">Net 60</SelectItem>
                      <SelectItem value="COD">Cash on Delivery</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <Separator />

              <div className="grid grid-cols-2 gap-4">
                <div className="flex items-center justify-between">
                  <Label htmlFor="tax-exemption" className="flex flex-col">
                    <span>Tax Exemption</span>
                    <span className="text-sm text-muted-foreground">Allow tax-exempt wholesale purchases</span>
                  </Label>
                  <Switch id="tax-exemption" checked={taxExemption} onCheckedChange={setTaxExemption} />
                </div>

                <div className="flex items-center justify-between">
                  <Label htmlFor="order-approval" className="flex flex-col">
                    <span>Order Approval</span>
                    <span className="text-sm text-muted-foreground">Require approval for wholesale orders</span>
                  </Label>
                  <Switch id="order-approval" checked={orderApproval} onCheckedChange={setOrderApproval} />
                </div>
              </div>

              <Separator />

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="stock-allocation">Stock Allocation</Label>
                  <Select value={stockAllocation} onValueChange={setStockAllocation}>
                    <SelectTrigger id="stock-allocation">
                      <SelectValue placeholder="Select allocation method" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="automatic">Automatic</SelectItem>
                      <SelectItem value="manual">Manual</SelectItem>
                      <SelectItem value="priority">Priority</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="returns-policy">Returns Policy</Label>
                  <Select value={returnsPolicy} onValueChange={setReturnsPolicy}>
                    <SelectTrigger id="returns-policy">
                      <SelectValue placeholder="Select policy" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="standard">Standard</SelectItem>
                      <SelectItem value="restricted">Restricted</SelectItem>
                      <SelectItem value="extended">Extended</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="payment-gateway">Payment Gateway</Label>
                  <Select value={paymentGateway} onValueChange={setPaymentGateway}>
                    <SelectTrigger id="payment-gateway">
                      <SelectValue placeholder="Select gateway" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="stripe">Stripe</SelectItem>
                      <SelectItem value="paypal">PayPal</SelectItem>
                      <SelectItem value="manual">Manual Processing</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </CardContent>
            <CardFooter className="flex justify-between">
              <Button variant="outline" type="button">
                <RefreshCw className="mr-2 h-4 w-4" />
                Reset
              </Button>
              <Button type="submit">
                <Save className="mr-2 h-4 w-4" />
                Save Changes
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>

        <TabsContent value="salesrep">
          <Card>
            <CardHeader>
              <CardTitle>Sales Representative Configuration</CardTitle>
              <CardDescription>Manage sales rep assignments and targets</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="salesrep-assign">Assignment Status</Label>
                <Select value={salesRepAssign} onValueChange={setSalesRepAssign}>
                  <SelectTrigger id="salesrep-assign">
                    <SelectValue placeholder="Select status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="enabled">Enabled</SelectItem>
                    <SelectItem value="disabled">Disabled</SelectItem>
                    <SelectItem value="auto-only">Auto Assignment Only</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="salesrep-targets">Monthly Sales Target (ZAR)</Label>
                <Input
                  id="salesrep-targets"
                  type="number"
                  value={salesRepTargets}
                  onChange={(e) => setSalesRepTargets(Number(e.target.value))}
                  min={0}
                />
              </div>
            </CardContent>
            <CardFooter className="flex justify-between">
              <Button variant="outline" type="button">
                <RefreshCw className="mr-2 h-4 w-4" />
                Reset
              </Button>
              <Button type="submit">
                <Save className="mr-2 h-4 w-4" />
                Save Changes
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>

        <TabsContent value="bulkorder">
          <Card>
            <CardHeader>
              <CardTitle>Bulk Order Configuration</CardTitle>
              <CardDescription>Manage bulk order settings and discounts</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="bulk-discount">Bulk Order Discount</Label>
                <Input
                  id="bulk-discount"
                  value={bulkOrderDiscount}
                  onChange={(e) => setBulkOrderDiscount(e.target.value)}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="bulk-payment-terms">Payment Terms</Label>
                <Select value={bulkOrderPaymentTerms} onValueChange={setBulkOrderPaymentTerms}>
                  <SelectTrigger id="bulk-payment-terms">
                    <SelectValue placeholder="Select terms" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Net15">Net 15</SelectItem>
                    <SelectItem value="Net30">Net 30</SelectItem>
                    <SelectItem value="Net60">Net 60</SelectItem>
                    <SelectItem value="Net90">Net 90</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
            <CardFooter className="flex justify-between">
              <Button variant="outline" type="button">
                <RefreshCw className="mr-2 h-4 w-4" />
                Reset
              </Button>
              <Button type="submit">
                <Save className="mr-2 h-4 w-4" />
                Save Changes
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>

        <TabsContent value="stokvel">
          <Card>
            <CardHeader>
              <CardTitle>Stokvel Group Configuration</CardTitle>
              <CardDescription>Manage stokvel group buying settings</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="stokvel-discount">Stokvel Bulk Discount</Label>
                <Input
                  id="stokvel-discount"
                  value={stokvelBulkDiscount}
                  onChange={(e) => setStokvelBulkDiscount(e.target.value)}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="stokvel-payment-schedule">Payment Schedule</Label>
                <Select value={stokvelPaymentSchedule} onValueChange={setStokvelPaymentSchedule}>
                  <SelectTrigger id="stokvel-payment-schedule">
                    <SelectValue placeholder="Select schedule" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="weekly">Weekly</SelectItem>
                    <SelectItem value="biweekly">Bi-weekly</SelectItem>
                    <SelectItem value="monthly">Monthly</SelectItem>
                    <SelectItem value="quarterly">Quarterly</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
            <CardFooter className="flex justify-between">
              <Button variant="outline" type="button">
                <RefreshCw className="mr-2 h-4 w-4" />
                Reset
              </Button>
              <Button type="submit">
                <Save className="mr-2 h-4 w-4" />
                Save Changes
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>
      </Tabs>
    </form>
  )
}

